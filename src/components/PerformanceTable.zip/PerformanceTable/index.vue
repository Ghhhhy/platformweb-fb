<!-- 专项业务经费 -->
<template>
  <div class="">
    <!-- 类excel表 -->
    <qy-table
      :table-config="columnConfig['top']"
      :data-obj.sync="tableData['top']"
      :type="type"
    />
    <!-- 类excel表 -->
    <qy-table
      :table-config="columnConfig['mid']"
      :data-obj.sync="tableData['mid']"
      :type="type"
      @data-insert="taskMethods"
      @currentRow="getCurrentRow"
    />
    <!-- 类table表 -->
    <qy-table
      :table-config.sync="columnConfig['bottom']"
      :data-obj.sync="tableData['bottom']"
      :type="type"
      @data-insert="dataInsert"
      @currentRow="getCurrentRow"
    />
    <!-- 指标库挑选 -->
    <PrjSelected
      v-if="showPrjSelected"
      ref="prjSelected"
      :unitdata="unitno"
      :targetname="secondTargetName"
      :first-ind-id="firstIndId"
      :second-ind-id="secondIndCode"
      :three-level-data="threeLevelData"
      @threeDataObj="threeDataObj"
    />
    <!-- 案例推送在底层button pop中 -->
  </div>
</template>

<script>
import qyTable from './table.vue'
import tableConfig from './config'
import PrjSelected from './components/PrjSelected.vue'
import { uuids } from '@/utils'
import jxUrl from '@/api/frame/main/projectLib/projectDeclarationManage/ProjectReport.js'

export default {
  name: 'PerformanceTable',
  components: { qyTable, PrjSelected },
  props: {
    validateCb: {
      type: Function,
      default() {
        // 函数，必须return 一个Promise
      }
    },
    formChangeData: {
      type: Object,
      default: () => { }
    },
    datalist: {
      type: Object,
      default: () => { }
    },
    crtTableType: {
      type: String,
      default: ''
    },
    customTableConfig: {
      type: Object,
      default: () => { }
    },
    type: {
      type: String,
      default: 'read'
    }
  },
  computed: {
  },
  data () {
    return {
      isRead: false, // 是否回显过数据
      unitno: '',
      operate: '',
      showPrjSelected: false,
      threeLevelData: [],
      secondTargetName: {},
      tableData: {
        top: [],
        mid: [],
        bottom: []
      },
      currentRow: null,
      firstIndId: '',
      secondIndId: '',
      secondIndCode: '',
      template_id: '',
      kpi_per_id: '',
      kpiPerId: '',
      templateId: '',
      defaultBottomData: { id: '0', indName: '绩效指标', children: [] },
      midData: [
        {
          'bgt_perf_goal_data$budgetAmt': 10000,
          'updateFlag': 'Appended',
          'bgt_perf_goal_data$payProName': '2',
          'bgt_perf_goal_data$deptFunc': '1',
          'id': 'row_105',
          'bgt_perf_goal_data$perfTask': '2'
        }
      ],
      columnConfig: null
    }
  },
  methods: {
    getDefaultBottomData() {
      let params = { }
      let that = this
      jxUrl.getTargetTree(params).then(res => {
        if (res.code === 0) {
          let data = res.content
          let list = []
          data.forEach(firstLevel => {
            let secondLevelData = []
            firstLevel.children.forEach(secondLevel => {
              let thirdLevelData = {}
              for (var key in secondLevel) {
                thirdLevelData[key] = null
              }
              thirdLevelData.id = uuids()
              thirdLevelData.levelNo = 3
              thirdLevelData.parentId = secondLevel.id
              let item = Object.assign({}, secondLevel)
              item.children = []
              item.children.push(thirdLevelData)
              secondLevelData.push(item)
            })

            let firstLevelData = Object.assign({}, firstLevel)
            firstLevelData.children = secondLevelData
            list.push(firstLevelData)
          })
          that.defaultBottomData.children = list
          if (that.type === 'create') {
            that.$set(that.tableData, 'bottom', that.formBottomData())
          }
        } else {
          console.log('查询一级二级指标失败!')
        }
      }).catch(err => {
        console.log(err)
      })
    },
    getCurrentRow (row) {
      this.currentRow = row
      this.firstIndId = this.currentRow.firstIndId
      this.secondIndId = this.currentRow.secondIndId
      this.secondIndCode = this.currentRow.secondIndCode
    },
    dataInsert (type, data) {
      switch (type) {
        case 'insert': // 指标库挑选
          this.threeLevelData = this.tableData['bottom'].filter(item => {
            return +item.levelNo === 3 && item.third
          })
          this.showPrjSelected = true

          break
        case 'push': // 案例推送数据处理
          // TODO  数据转义
          console.log(data, 'index-data-push')
          let val = { 'target_dto': data.target, 'base_dto': data.base }
          this.formateData(val)
          break
        case 'reset': // 重置
          this.tableData['bottom'] = this.tableData['bottom'].map(item => {
            return {
              ...item,
              targetCharacter: '',
              third: '',
              fifth: '',
              fourth: '',
              sixth: '',
              seventh: '',
              eighth: ''
            }
          })
          break

        default:
          break
      }
    },
    taskMethods (type, data) {
      switch (type) {
        case 'addTask': // 新增任务
          this.addTask()
          break
        case 'deleteTask': // 新增任务
          this.deleteTask()
          break
        case 'addt':
          this.addt()
          break
        case 'deletet':
          this.deletet()
          break
        default:
          break
      }
    },
    // 挑选项目的弹框数据渲染
    threeDataObj (val) {
      let self = this
      val.forEach(item => {
        const obj = {
          ...self.currentRow,
          ...item,
          third: item.indName,
          targetCharacter: item.targetCharacter,
          fourth: item.targetDirection,
          fifth: item.cytValue,
          sixth: item.calculation,
          seventh: item.targetRemark,
          eighth: item.targetWeight
        }
        if (self.tableData['bottom'][self.currentRow.rowIndex].third === '' || this.tableData['bottom'][this.currentRow.rowIndex].third === null) {
          self.tableData['bottom'].splice(self.currentRow.rowIndex, 1, obj)
        } else {
          let num = self.tableData['bottom'].length - 1
          for (let i = num; i >= 0; i--) {
            if (self.currentRow.secondIndId === self.tableData['bottom'][i].secondIndId) {
              self.tableData['bottom'].splice(i + 1, 0, obj)
              break
            }
          }
        }
      })
    },
    // 新增任务
    addTask () {
      const obj = {
        first: '年度主要任务',
        second: '',
        third: ''
      }
      this.tableData['mid'].splice(0, 0, obj)
    },
    // 删除任务
    deleteTask () {
      this.tableData['mid'].splice(0, 1)
    },
    addt () {
      const obj = {
        first: '年度履职目标',
        second: '',
        third: ''
      }
      this.tableData['mid'].splice(0, 0, obj)
    },
    // 删除任务
    deletet () {
      this.tableData['mid'].splice(0, 1)
    },
    formateData (val) {
      val && (this.backup = JSON.parse(JSON.stringify(val))) // 数据备份，用以提交时数据反编译
      if (val && val.target_dto && val.target_dto.length > 0) {
        this.$set(this.tableData, 'bottom', this.formBottomData((val && val.target_dto) || {}))
      } else {
        this.getDefaultBottomData()
      }
      this.$set(this.tableData, 'top', this.formTopData(val && val.big_field, (val && val.base_dto) || {}))
      this.$set(this.tableData, 'mid', this.formMidData(val && val.bgtPerfGoalData))
    },
    formMidData (bgtPerfGoalData) {
      if (!this.columnConfig) {
        return
      }
      if (bgtPerfGoalData) {
        return bgtPerfGoalData
      } else {
        return []
      }
    },
    formTopData (bigField, baseDto) {
      if (!this.columnConfig) {
        return
      }
      let topDataMap = this.columnConfig.topDataMap || {}
      const list = this.columnConfig.defaultTopData
      if (baseDto) {
        if (baseDto.pushAllTarget) { // 推送的目标特殊处理
          switch (this.crtTableType) {
            case 'zxywjf':
            case 'zxywjfys':
            case 'zxzjxmjx':
              list[9].first = baseDto.pushAllTarget
              break
            case 'zxzj':
            case 'zxzjtype':
            case 'allzxzjtype':
            case 'auditzxzjtype':
              list[6].first = baseDto.pushAllTarget
              break
            case 'deptjx':
              break
            default:
              Object.keys(topDataMap).forEach((key) => {
                let keyMapArr = key.split('__')
                list[keyMapArr[0]][keyMapArr[1]] = baseDto[topDataMap[key].field]
              })
              this.kpiPerId = baseDto.kpiPerId
              this.templateId = baseDto.templateId
              break
          }
        } else {
          switch (this.crtTableType) {
            case 'zxywjf':
            case 'zxywjfys':
              list[0].second = baseDto.pro_code
              list[1].second = baseDto.pro_name
              list[2].second = baseDto.dep_unitname
              list[3].second = baseDto.agency_name
              list[4].third = baseDto.amt
              list[5].second = baseDto.publicFunds
              list[6].second = baseDto.allOtherMoney
              list[7].second = 10
              list[9].first = baseDto.all_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            case 'zxzj':
              list[0].second = baseDto.pro_name
              list[1].second = baseDto.dep_unitname
              list[2].third = baseDto.amt
              list[3].second = baseDto.publicFunds
              list[4].second = baseDto.allOtherMoney
              list[2].fifth = baseDto.totalMoneyYear
              list[3].fourth = baseDto.publicFundsYear
              list[4].fourth = baseDto.allOtherMoneyYear
              list[6].first = baseDto.all_target
              list[6].second = baseDto.year_target
              break
            case 'zxzjtype':
              list[0].second = baseDto.pro_name
              list[1].second = baseDto.dep_unitname
              list[2].third = baseDto.amt
              list[3].second = baseDto.publicFunds
              list[4].second = baseDto.allOtherMoney
              list[2].fifth = baseDto.totalMoneyYear
              list[3].fourth = baseDto.publicFundsYear
              list[4].fourth = baseDto.allOtherMoneyYear
              list[6].first = baseDto.all_target
              list[6].second = baseDto.year_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            case 'allzxzjtype':
              list[0].second = baseDto.pro_name
              list[1].second = baseDto.dep_unitname
              list[2].third = baseDto.amt
              list[3].second = baseDto.publicFunds
              list[4].second = baseDto.allOtherMoney
              list[2].fifth = baseDto.totalMoneyYear
              list[3].fourth = baseDto.publicFundsYear
              list[4].fourth = baseDto.allOtherMoneyYear
              list[6].first = baseDto.all_target
              list[6].second = baseDto.year_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            case 'auditzxzjtype':
              list[0].second = baseDto.pro_name
              list[1].second = baseDto.dep_unitname
              list[2].third = baseDto.amt
              list[3].second = baseDto.publicFunds
              list[4].second = baseDto.allOtherMoney
              list[2].fifth = baseDto.totalMoneyYear
              list[3].fourth = baseDto.publicFundsYear
              list[4].fourth = baseDto.allOtherMoneyYear
              list[6].first = baseDto.all_target
              list[6].second = baseDto.year_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            case 'zxzjxmjx':
              list[0].second = baseDto.pro_code
              list[1].second = baseDto.pro_name
              list[2].second = baseDto.dep_unitname
              list[3].second = baseDto.agency_name
              list[4].third = baseDto.amt
              list[5].second = baseDto.publicFunds
              list[6].second = baseDto.allOtherMoney
              list[7].second = 10
              list[9].first = baseDto.all_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            case 'deptjx':
              list[0].second = baseDto.dep_unitnoname
              list[1].second = baseDto.mof_dep_name
              list[3].first = baseDto.year_target
              this.kpi_per_id = baseDto.kpi_per_id
              this.template_id = baseDto.template_id
              break
            default:
              Object.keys(topDataMap).forEach((key) => {
                let keyMapArr = key.split('__')
                this.$set(list[keyMapArr[0]], keyMapArr[1], baseDto[topDataMap[key].field])
                // list[keyMapArr[0]][keyMapArr[1]] = baseDto[topDataMap[key].field]
              })
              this.kpiPerId = baseDto.kpiPerId
              this.templateId = baseDto.templateId
              break
          }
        }
      } else { // 年度目标存在缓存，先这么处理
        switch (this.crtTableType) {
          case 'zxywjf':
          case 'zxywjfys':
          case 'zxzjxmjx':
            list[9].first = ''
            break
          case 'zxzj':
          case 'zxzjtype':
          case 'allzxzjtype':
          case 'auditzxzjtype':
            list[6].first = ''
            list[6].second = ''
            break
          case 'deptjx':
            list[3].first = ''
            break

          default:
            Object.keys(topDataMap).forEach((key) => {
              let keyMapArr = key.split('__')
              list[keyMapArr[0]][keyMapArr[1]] = baseDto[topDataMap[key].field]
            })
            break
        }
      }

      return list
    },
    formBottomData (data) {
      if (!this.columnConfig) {
        return
      }
      let tree, level3Data, arr
      if (data) { // 有data即为回显数据
        this.isRead = true
        data.push({ indName: '绩效指标', id: '0', indId: '0', children: null })
        tree = this.translateDataToTree(data)
        const treeForeach = (tree, result = []) => {
          for (const item of tree) {
            if (+item.levelNo === 2 && (!item.children || !item.children.length)) {
              item.children = []
              item.children.push({
                parentId: item.id,
                levelNo: 3,
                id: uuids(),
                secondIndCode: item.indId
              })
            }
            if (+item.levelNo === 3) {
              if (item.indCode) {
                item.secondIndCode = item.indCode.trim().substr(0, 8) // 这么处理可能有隐患
              }
              result.push(item)
            }
            item.children && treeForeach(item.children, result)
          }
          return result
        }
        level3Data = treeForeach(tree)
        this.bottomDefaultRree = tree
      } else { // 否则使用默认数据
        this.isRead = false
        tree = this.defaultBottomData
        arr = tree.children
        for (let i = 0; i < arr.length; i++) {
          if (+arr[i].levelNo === 1) {
            arr[i].id = arr[i].indId
            arr[i].tempId = arr[i].indId
            arr[i].project_id = uuids()
            if (!arr[i].children) return
            for (let k = 0; k < arr[i].children.length; k++) {
              arr[i].children[k].id = arr[i].children[k].indId
              arr[i].children[k].tempId = arr[i].children[k].indId
              arr[i].children[k].parentId = arr[i].indId
              arr[i].children[k].parent_target_id = arr[i].children[k].parentId
              arr[i].children[k].project_id = arr[i].project_id
              for (let kk = 0; kk < arr[i].children[k].children.length; kk++) {
                arr[i].children[k].children[kk].id = uuids()
                arr[i].children[k].children[kk].tempId = arr[i].children[k].children[kk].id
                arr[i].children[k].children[kk].parentId = arr[i].children[k].id
                arr[i].children[k].children[kk].parent_parent_id = arr[i].children[k].parentId
                arr[i].children[k].children[kk].parent_target_id = arr[i].children[k].id
                arr[i].children[k].children[kk].project_id = arr[i].project_id
              }
            }
          }
        }
        level3Data = this.treeForeach(arr, item => +item.levelNo === 3)
        tree = [tree]
        this.bottomDefaultRree = tree
      }
      return this.formlevel3(level3Data, tree)
    },
    // 树遍历
    treeForeach (tree, func, result = []) {
      for (const data of tree) {
        if (func(data)) {
          var item = JSON.parse(JSON.stringify(data))
          delete item.children
          result.push(item)
        }
        data.children && this.treeForeach(data.children, func, result)
      }
      return result
    },
    // 转换成树状结构
    translateDataToTree (data) {
      let parents = data.filter(value => !value.parentGtId)
      let children = data.filter(value => value.parentGtId)
      let translator = (parents, children) => {
        parents.forEach((parent) => {
          children.forEach((current, index) => {
            if (current.parentGtId === parent.id) {
              let temp = JSON.parse(JSON.stringify(children))
              temp.splice(index, 1)
              translator([current], temp)
              parent.children ? parent.children.push(current) : parent.children = [current]
            }
          }
          )
        }
        )
      }
      translator(parents, children)
      return parents
    },
    // 查找多个节点
    treeFindEvery (tree, func, path = [], result = []) {
      for (const data of tree) {
        path.push(data)
        func(data) && result.push([...path])
        data.children && this.treeFindEvery(data.children, func, path, result)
        path.pop()
      }
      return result
    },
    // 查找节点
    treeFind (tree, func) {
      for (const data of tree) {
        if (func(data)) return data
        if (data.children) {
          const res = this.treeFind(data.children, func)
          if (res) return res
        }
      }
      return null
    },
    treeFindItems (tree, func, result = []) {
      for (const data of tree) {
        if (func(data)) {
          let item = JSON.parse(JSON.stringify(data))
          delete item.children
          result.push(item)
        }
        if (data.children) {
          this.treeFindItems(data.children, func, result)
        }
      }
      return result
    },
    formlevel3 (level3Data, tree) {
      const arr = []
      let bottomDataMap = this.columnConfig.bottomDataMap || {}
      if (this.columnConfig.bottom.thList.data[4].childrenProp) {
        this.columnConfig.bottom.thList.data[4].childrenProp.disabledRows = []
      }
      if (this.columnConfig.bottom.thList.data[7].childrenProp) {
        this.columnConfig.bottom.thList.data[7].childrenProp.disabledRows = []
      }
      for (let i = 0, num = level3Data.length; i < num; i++) {
        let item = level3Data[i]
        let k = this.treeFindEvery(tree, node => node.id === item.id)[0]
        const keys = ['zeroth', 'first', 'second', 'third']
        const obj = {}
        keys.forEach((kk, vv) => {
          obj[kk] = k[vv] ? k[vv]['indName'] : ''
        })
        if (item.targetCharacter && item.targetCharacter === 3) {
          this.columnConfig.bottom.thList.data[4].childrenProp.disabledRows.push(i)
          this.columnConfig.bottom.thList.data[7].childrenProp.disabledRows.push(i)
        }
        obj.targetCharacter = k[k.length - 1].targetCharacter
        obj.fourth = k[k.length - 1].targetDirection
        obj.fifth = k[k.length - 1].cytValue
        obj.sixth = k[k.length - 1].calculation
        obj.seventh = k[k.length - 1].targetRemark
        obj.eighth = k[k.length - 1].targetWeight
        obj.firstIndId = k[k.length - 1].parent_parent_id
        obj.secondIndId = k[k.length - 1].parentId
        Object.keys(bottomDataMap).forEach((key) => {
          obj[key] = k[k.length - 1][bottomDataMap[key].field]
        })
        Object.assign(obj, item)
        arr.push(obj)
      }
      return arr
    },
    getSecondId (targetName, levelNo = 2) {
      let item
      // 查找父级id，父级project_id
      if (!this.isRead) {
        item = this.treeFind(this.bottomDefaultRree, node => node.indName === targetName && +node.levelNo === levelNo)
      } else {
        [item] = this.backup.target_dto.filter(k => {
          return k.indName === targetName && +k.levelNo === levelNo
        })
      }
      return { parentId: item.id, projectId: item.project_id, indCode: item.indCode }
    },
    validation ({ top, bottomData }) {
      var obj = {}
      if ((this.crtTableType === 'zxzj' || this.crtTableType === 'zxywjf' || this.crtTableType === 'zxywjfys') && (!top[9].first)) {
        this.$message({ message: '项目年度目标不能为空', type: 'warning' })
        return false
      }
      if ((this.crtTableType === 'zxzj') && !top[8].second) {
        this.$message({ message: '年度目标不能为空', type: 'warning' })
        return false
      }
      const bottom = bottomData.reduce((item, next) => {
        if (obj[next.parentId]) {
          obj[next.parentId] = true
          item.push(next)
        }
        return item
      }, [])
      const arr = bottom.filter(item => {
        return item.third
      })
      if (arr.length === 0) {
        this.$message({ message: '三级指标不能为空!', type: 'warning' })
        return false
      }
      return true
    },
    // validCellRules(cellValue, rules) { // 校验单元格
    //   const errorRules = []
    //   if (rules) {
    //     rules.forEach(rule => {
    //       const isNumber = rule.type === 'number'
    //       const numVal = isNumber ? (isNaN(parseFloat(cellValue)) ? 0 : parseFloat(cellValue)) : String(cellValue).length
    //       if (rule.required && (cellValue === null || cellValue === undefined || cellValue === '')) {
    //         errorRules.push(rule)
    //       } else if (
    //         (isNumber && isNaN(cellValue)) ||
    //         (!isNaN(rule.min) && numVal < parseFloat(rule.min)) ||
    //         (!isNaN(rule.max) && numVal > parseFloat(rule.max)) ||
    //         (rule.pattern && !(rule.pattern.test ? rule.pattern : new RegExp(rule.pattern)).test(cellValue))
    //       ) {
    //         errorRules.push(rule)
    //       }
    //     })
    //   }
    //   return errorRules
    // },
    newRule(rule) { // 错误规则信息
      return Object.assign({}, {
        $options: rule,
        required: rule.required,
        min: rule.min,
        max: rule.min,
        type: rule.type,
        pattern: rule.pattern,
        validator: rule.validator,
        maxWidth: rule.maxWidth,
        message: rule.message
      })
    },
    validCellRules({ datalist, cellValue, rules, DataMap }) { // 校验单元格
      let self = this
      try {
        const errorRules = []
        const syncVailds = []
        if (rules) {
          rules.forEach(rule => {
            if (typeof self.validateCb === 'function' && rule.asyncValidate) {
              let customValid
              customValid = self.validatorCb({
                cellValue,
                rule,
                rules,
                datalist,
                DataMap
              })
              if (customValid) {
                if (self.getbasicDataType(customValid) === 'Error') {
                  errorRules.push(self.newRule({ message: customValid.message, rule: self.newRule(rule) }))
                } else if (customValid.catch) {
                  // 如果为异步校验（注：异步校验是并发无序的）
                  syncVailds.push(
                    customValid.catch(e => {
                      errorRules.push(self.newRule({ type: 'custom', message: e ? e.message : rule.message, rule: self.newRule(rule) }))
                    })
                  )
                }
              }
            } else {
              const isNumber = rule.type === 'number'
              const numVal = isNumber ? (isNaN(parseFloat(cellValue)) ? 0 : parseFloat(cellValue)) : String(cellValue || '').length
              if (rule.required && (cellValue === null || cellValue === undefined || cellValue === '')) {
                self.validRuleErr = true
                errorRules.push(self.newRule(rule))
              } else if (rule.required && ((isNumber && isNaN(cellValue)) || (!isNaN(rule.min) && numVal < parseFloat(rule.min)) || (!isNaN(rule.max) && numVal > parseFloat(rule.max)) || (rule.pattern && !(rule.pattern.test ? rule.pattern : new RegExp(rule.pattern)).test(cellValue)))) {
                errorRules.push(self.newRule(rule))
              }
            }
          })
        }
        return Promise.all(syncVailds).then(() => {
          if (errorRules.length) {
            const rest = { rules: errorRules, rule: errorRules[0] }
            return Promise.reject(rest)
          }
        })
      } catch (e) {
      }
    },
    validate ({ top, threeLevelData, taskData }) {
      return this.beginValidate({ top, threeLevelData, taskData })
    },
    beginValidate ({ top, threeLevelData, taskData }) {
      let self = this
      let dataList = self.saveData(() => {}, 'getData')
      const itemValids = []
      let errorRules = []
      let { topDataMap = {}, bottomDataMap = {} } = self.columnConfig
      Object.keys(topDataMap).forEach((key) => {
        let keyMapArr = key.split('__')
        if (topDataMap[key].validator) {
          itemValids.push(self.validCellRules({ DataMap: topDataMap[key], cellValue: [keyMapArr[0]] && top[keyMapArr[0]][keyMapArr[1]], rules: topDataMap[key].validator, dataList }).then(() => {
          }).catch(({ rule, rules }) => {
            return Promise.reject(errorRules = errorRules.concat(rules))
          }))
        }
      })
      for (let i = 0; i < threeLevelData.length; i++) {
        Object.keys(bottomDataMap).forEach((key) => {
          if (bottomDataMap[key].validator) {
            itemValids.push(self.validCellRules({ DataMap: bottomDataMap[key], cellValue: threeLevelData[i][key], rules: bottomDataMap[key].validator, dataList }).then(() => {
            }).catch(({ rule, rules }) => {
              return Promise.reject(errorRules = errorRules.concat(rules))
            }))
          }
        })
      }
      return Promise.all(itemValids).then(() => {
      }).catch(() => {
        return Promise.reject(errorRules)
      })
    },
    validationData ({ top, threeLevelData, taskData }) {
      let self = this
      return new Promise((resolve, reject) => {
        if (self.crtTableType) {
          let flage = true
          if ((self.crtTableType === 'zxzj' || self.crtTableType === 'zxywjf' || self.crtTableType === 'zxywjfys') && (!top[9].first)) {
            self.$message({ message: '项目年度目标不能为空', type: 'warning' })
            flage = false
          } else if ((self.crtTableType === 'zxzj' || self.crtTableType === 'zxywjf' || self.crtTableType === 'zxywjfys') && top[9].first) {
            if (top[9].first.length < 20 || top[9].first.length > 150) {
              self.$message({ message: '项目年度目标字数不符合，20~150字', type: 'warning' })
              flage = false
            }
          } else {}
          if ((self.crtTableType === 'zxzj') && !top[8].second) {
            self.$message({ message: '年度目标不能为空', type: 'warning' })
            flage = false
          }
          if (threeLevelData.length === 0) {
            self.$message({ message: '三级指标不能为空!', type: 'warning' })
            flage = false
          }
          if (self.crtTableType === 'deptjx') {
            if (!top[3].first) {
              self.$message({ message: '年度目标不能为空', type: 'warning' })
              flage = false
            }
            if (taskData.length === 0) {
              self.$message({ message: '任务不能为空', type: 'warning' })
              flage = false
            }
            let taskFlage = true
            taskData.forEach(item => {
              if (!item.second || !item.third) {
                self.$message({ message: '任务名称和主要内容不能为空', type: 'warning' })
                taskFlage = false
                flage = false
              }
            })
            if (!taskFlage) {
              flage = false
            }
          }
          let allWeight = 0

          let Outputindicators = 0
          let Benefitindex = 0
          let Satisfactionindex = 0
          let Outputindicatorsname = '产出指标'
          let Benefitindexname = '效益指标'
          let Satisfactionindexname = '满意度指标'
          for (let i = 0; i < threeLevelData.length; i++) {
            let item = threeLevelData[i]
            let rowIndName = item.indName || `第${item.rowIndex + 1}行，${item.first} > ${item.second}`
            if (!item.third) {
              self.$message({ message: '请输入指标【' + rowIndName + '】三级指标名称', type: 'warning' })
              flage = false
            } else if (item.third.length > 26) {
              self.$message({ message: '【' + rowIndName + '】三级指标名称字数不符合，不能超过26个字', type: 'warning' })
              flage = false
            }
            if (!item.targetCharacter) {
              self.$message({ message: '请输入指标【' + rowIndName + '】指标性质', type: 'warning' })
              flage = false
            }
            if (!item.fourth && item.targetCharacter !== 3) {
              self.$message({ message: '请输入指标【' + rowIndName + '】指标方向', type: 'warning' })
              flage = false
            }
            if (!item.fifth) {
              self.$message({ message: '请输入指标【' + rowIndName + '】目标值', type: 'warning' })
              flage = false
            }
            if (!item.sixth && item.targetCharacter !== 3) {
              self.$message({ message: '请输入指标【' + rowIndName + '】计量单位', type: 'warning' })
              flage = false
            }
            if (!item.eighth && self.crtTableType !== 'deptjx' && self.crtTableType !== 'allzxzjtype') {
              self.$message({ message: '请输入指标【' + rowIndName + '】分值', type: 'warning' })
              flage = false
            }
            if (item.targetWeight) {
              allWeight = (Number)(item.targetWeight) + (Number)(allWeight)
            }
            if (item.first === Outputindicatorsname) {
              Outputindicators += (Number)(item.targetWeight) // (Number)(item.targetWeight) + (Number)(targetWeight)
            }
            if (item.first === Benefitindexname) {
              Benefitindex += (Number)(item.targetWeight)
            }
            if (item.first === Satisfactionindexname) {
              Satisfactionindex += (Number)(item.targetWeight)
            }
          }
          // threeLevelData.forEach(item => {
          //   let rowIndName = item.indName || `第${item.rowIndex+1}行，${item.first} > ${item.second}`
          //   if (!item.third) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】三级指标名称', type: 'warning' })
          //     flage = false
          //     return false
          //   }else if(item.third.length > 26){
          //     self.$message({ message: '【' + rowIndName + '】三级指标名称字数不符合，不能超过26个字', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (!item.targetCharacter) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】指标性质', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (!item.fourth && item.targetCharacter !== 3) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】指标方向', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (!item.fifth) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】目标值', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (!item.sixth && item.targetCharacter !== 3) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】计量单位', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (!item.eighth) {
          //     self.$message({ message: '请输入指标【' + rowIndName + '】分值', type: 'warning' })
          //     flage = false
          //     return false
          //   }
          //   if (item.targetWeight) {
          //     allWeight = (Number)(item.targetWeight) + (Number)(allWeight)
          //   }
          //   if (item.first === Outputindicatorsname) {
          //     Outputindicators += (Number)(item.targetWeight); // (Number)(item.targetWeight) + (Number)(targetWeight)
          //   }
          //   if (item.first === Benefitindexname) {
          //     Benefitindex+= (Number)(item.targetWeight);
          //   }
          //   if (item.first === Satisfactionindexname) {
          //     Satisfactionindex+= (Number)(item.targetWeight);
          //   }
          // })
          if (self.crtTableType !== 'deptjx' && self.crtTableType !== 'allzxzjtype') {
            let proCatCode = self.formChangeData.proCatCode
            if (proCatCode != null && (proCatCode.trim().substr(0, 2) === '21' || proCatCode.trim().substr(0, 1) === '1')) {} else {
              if (Outputindicators.toString() !== '50') {
                self.$message({ message: Outputindicatorsname + '分值之和应等于50!', type: 'warning' })
                flage = false
              }
              if (Benefitindex.toString() !== '30') {
                self.$message({ message: Benefitindexname + '分值之和应等于30!', type: 'warning' })
                flage = false
              }
              if (Satisfactionindex.toString() !== '10') {
                self.$message({ message: Satisfactionindexname + '分值之和应等于10!', type: 'warning' })
                flage = false
              }
            }
            if (allWeight !== 90) {
              self.$message({ message: '绩效目标表三级指标分值总和不等于90!', type: 'warning' })
              flage = false
            }
          }
          if (!flage) {
            reject(new Error('校验没通过'))
          } else {
            resolve(true)
          }
        } else {
          // let errorRules = []
          // let { topDataMap = {}, bottomDataMap = {} } = self.columnConfig
          // Object.keys(topDataMap).forEach((key) => {
          //   let keyMapArr = key.split('__')
          //   if (topDataMap[key].validator) {
          //     errorRules = errorRules.concat(self.validCellRules(top[keyMapArr[0]] && top[keyMapArr[0]][keyMapArr[0]], topDataMap[key].validator))
          //   }
          // })
          self.validate({ top, threeLevelData, taskData }).then(() => {
            resolve(true)
          }).catch(errorRules => {
            if (errorRules.length) {
              self.$message({
                showClose: true,
                dangerouslyUseHTMLString: true,
                duration: 30000,
                message: `<strong class="cred f14">绩效校验没通过'</br>'${errorRules.map(item => item.message).join('</br>')}</strong>`
              })
              reject(new Error('校验没通过'))
            } else {
              resolve(true)
            }
          })
        }
      })
    },
    /**
     * @description:
     * @param {*} cb: function  将data作为参数进行回调
     * @param {*} type: save 保存 || keep 暂存
     * @author: 轻语
     */
    saveData (cb, type = 'save') {
      let self = this
      const { top, mid, bottom } = self.tableData

      // 校验三级指标数据
      // let bottomData = bottom.map((item, index) => {
      //     return {
      //         indName: item['third'],
      //         indCode:item['indCode'],
      //         levelNo: 3
      //     }
      // })
      let bottomData = Object.assign([], bottom)
      let taskData
      let threeLevelData = bottomData.filter(item => {
        // 增加需求，任意一列有值，其他列都需要填写
        // return +item.levelNo === 3 && item.third //原判断，只验证填写三级指标行
        return +item.levelNo === 3 && (item.ind_name || item.third || item.fourth || item.targetCharacter || item.fifth || item.sixth || item.seventh || item.eighth)
      })
      let bottomDataMap = self.columnConfig.bottomDataMap || {}
      threeLevelData.forEach(item => {
        if (!item.indName || item.indName === '') {
          item.indName = item.third
        }
        // item.targetCharacter = item.targetCharacter
        if (!item.targetDirection || item.targetDirection === '') {
          item.targetDirection = item.fourth
        }
        if (!item.cytValue || item.cytValue === '') {
          item.cytValue = item.fifth
        }
        if (!item.calculation || item.calculation === '') {
          item.calculation = item.sixth
        }
        if (!item.targetRemark || item.targetRemark === '') {
          item.targetRemark = item.seventh
        }
        if (!item.targetWeight || item.targetWeight === '') {
          item.targetWeight = item.eighth
        }
        if (!item.parentId || item.parentId === '') {
          item.parentId = item.secondIndId
        }
        Object.keys(bottomDataMap).forEach((key) => {
          item[bottomDataMap[key].field] = item[bottomDataMap[key]]
        })
      })
      if (type !== 'keep') {
        // if (self.crtTableType === 'deptjx') {
        taskData = Object.assign([], mid)
        // }
        // 基本支出项目不校验

        if (self.formChangeData.isgen && (self.formChangeData.isgen === 1 || self.formChangeData.isgen === 2)) {
          return self.saveDataNext({ top, threeLevelData, taskData }, cb)
        } else {
          if (type === 'save') {
            self.validationData({ top, threeLevelData, taskData }).then(res => {
              self.saveDataNext({ top, threeLevelData, taskData }, cb)
            }).catch((errorRules) => {
              // eslint-disable-next-line standard/no-callback-literal
              typeof cb === 'function' && cb(false)
            })
          } else {
            return self.saveDataNext({ top, threeLevelData, taskData }, cb)
          }
        }
      } else {
        return self.saveDataNext({ top, threeLevelData, taskData }, cb)
      }
    },
    saveDataNext({ top, threeLevelData, taskData }, cb) {
      // 合并三级之前的数据
      let data = {}
      let otherBottom
      if (this.type === 'read') {
        otherBottom = this.backup.target_dto.filter(item => {
          return +item.levelNo !== 3
        })
      } else {
        otherBottom = this.treeFindItems(this.bottomDefaultRree[0].children ? this.bottomDefaultRree[0].children : this.bottomDefaultRree[1].children, node => +node.levelNo !== 3)
      }
      data.target_dto = threeLevelData.concat(otherBottom)
      switch (this.crtTableType) {
        case 'zxywjf':
        case 'zxywjfys':

          // this.tableData['top'][2].fifth = val.totalMoneyYear
          // this.tableData['top'][3].fourth = val.publicFundsYear
          // this.tableData['top'][4].fourth = val.allOtherMoneyYear
          // this.tableData['top'][6].second = val.year_target
          let base = {
            all_target: top[9].first,
            goal_amt: top[4].third,
            publicFunds: top[5].second,
            allOtherMoney: top[6].second,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }

          // TODO 拼凑top数据
          data.base_dto = base

          break
        case 'zxzjxmjx':
          let xmjxdata = {
            all_target: top[9].first,
            goal_amt: top[4].third,
            publicFunds: top[5].second,
            allOtherMoney: top[6].second,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }

          // TODO 拼凑top数据
          data.base_dto = xmjxdata

          break
        case 'zxzj':
          let zxzjbase = {
            all_target: top[6].first,
            amt: top[2].third,
            publicFunds: top[3].second,
            allOtherMoney: top[4].second,
            totalMoneyYear: top[2].fifth,
            publicFundsYear: top[3].fourth,
            allOtherMoneyYear: top[4].fourth,
            year_target: top[6].second
          }
          // TODO 拼凑top数据
          data.base_dto = zxzjbase
          break
        case 'zxzjtype':
          let zxzjdata = {
            all_target: top[6].first,
            amt: top[2].third,
            publicFunds: top[3].second,
            allOtherMoney: top[4].second,
            totalMoneyYear: top[2].fifth,
            publicFundsYear: top[3].fourth,
            allOtherMoneyYear: top[4].fourth,
            year_target: top[6].second,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }
          data.base_dto = zxzjdata
          break
        case 'allzxzjtype':
          let allzxzjdata = {
            all_target: top[6].first,
            amt: top[2].third,
            publicFunds: top[3].second,
            allOtherMoney: top[4].second,
            totalMoneyYear: top[2].fifth,
            publicFundsYear: top[3].fourth,
            allOtherMoneyYear: top[4].fourth,
            year_target: top[6].second,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }
          data.base_dto = allzxzjdata
          break
        case 'auditzxzjtype':
          let auditzxzjdata = {
            all_target: top[6].first,
            amt: top[2].third,
            publicFunds: top[3].second,
            allOtherMoney: top[4].second,
            totalMoneyYear: top[2].fifth,
            publicFundsYear: top[3].fourth,
            allOtherMoneyYear: top[4].fourth,
            year_target: top[6].second,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }
          data.base_dto = auditzxzjdata
          break
        case 'deptjx':
          let deptjxData = {
            dep_unitnoname: top[0].second,
            mof_dep_name: top[1].second,
            year_target: top[3].first,
            kpi_per_id: this.kpi_per_id,
            template_id: this.template_id
          }
          data.base_dto = deptjxData
          data.bgtPerfGoalData = taskData
          break
        default:
          let baseDefault = {}
          let topDataMap = this.columnConfig.topDataMap || {}
          Object.keys(topDataMap).forEach((key) => {
            let keyMapArr = key.split('__')
            baseDefault[topDataMap[key].field] = top[keyMapArr[0]] && top[keyMapArr[0]][keyMapArr[1]]
          })
          baseDefault['kpiPerId'] = this.kpiPerId
          baseDefault['templateId'] = this.templateId
          data.base_dto = baseDefault
          data.bgtPerfGoalData = taskData
          break
      }
      cb && cb(data)
      return data
    },
    deepCopy(obj) {
      // 深拷贝通用方法
      let me = this
      let newObj = null
      if (typeof obj !== 'object' || obj === null) {
        newObj = obj
      } else {
        if (obj instanceof Array) {
          newObj = obj.map((item, index) => {
            return me.deepCopy(item)
          })
        } else if (obj instanceof Object) {
          newObj = {}
          for (let key in obj) {
            newObj[key] = me.deepCopy(obj[key])
          }
        } else if (obj instanceof Map) {
          newObj = new Map()
          obj.keys().forEach((mapV, mapK) => {
            newObj.set(mapK, me.deepCopy(mapV))
          })
        } else if (obj instanceof Set) {
          newObj = new Map()
          Set.forEach((setV, setI) => {
            newObj.add(me.deepCopy(setV))
          })
        } else {
        }
      // eslint-disable-next-line no-proto
      // newObj.__proto__ = obj.__proto__
      }
      return newObj
    },
    setFormChangeData(val) { // 设置 基础 data
      if (!val || !this.columnConfig) return
      switch (this.crtTableType) {
        case 'zxywjf':
        case 'zxywjfys':
          this.tableData['top'][0].second = val.pro_code
          this.tableData['top'][1].second = val.pro_name
          this.tableData['top'][2].second = val.dep_unitname
          this.tableData['top'][3].second = val.agency_name
          this.tableData['top'][4].third = val.amt
          this.tableData['top'][5].second = val.publicFunds
          this.tableData['top'][6].second = val.allOtherMoney
          this.tableData['top'][7].second = 10
          // this.tableData['top'][9].first = val.year_target
          break
        case 'zxzjxmjx':
          this.tableData['top'][0].second = val.pro_code
          this.tableData['top'][1].second = val.pro_name
          this.tableData['top'][2].second = val.dep_unitname
          this.tableData['top'][3].second = val.agency_name
          this.tableData['top'][4].third = val.amt
          this.tableData['top'][5].second = val.publicFunds
          this.tableData['top'][6].second = val.allOtherMoney
          this.tableData['top'][7].second = 10
          break
        case 'zxzj':
          this.tableData['top'][0].second = val.pro_name
          this.tableData['top'][1].second = val.dep_unitname
          this.tableData['top'][2].third = val.amt
          this.tableData['top'][3].second = val.publicFunds
          this.tableData['top'][4].second = val.allOtherMoney
          this.tableData['top'][2].fifth = val.totalMoneyYear
          this.tableData['top'][3].fourth = val.publicFundsYear
          this.tableData['top'][4].fourth = val.allOtherMoneyYear
          // this.tableData['top'][6].first = val.all_target
          // this.tableData['top'][6].second = val.year_target
          break
        case 'zxzjtype':
          this.tableData['top'][0].second = val.pro_name
          this.tableData['top'][1].second = val.dep_unitname
          this.tableData['top'][2].third = val.amt
          this.tableData['top'][3].second = val.publicFunds
          this.tableData['top'][4].second = val.allOtherMoney
          this.tableData['top'][2].fifth = val.totalMoneyYear
          this.tableData['top'][3].fourth = val.publicFundsYear
          this.tableData['top'][4].fourth = val.allOtherMoneyYear
          this.tableData['top'][6].first = val.all_target
          this.tableData['top'][6].second = val.year_target
          break
        case 'allzxzjtype':
          this.tableData['top'][0].second = val.pro_name
          this.tableData['top'][1].second = val.dep_unitname
          this.tableData['top'][2].third = val.amt
          this.tableData['top'][3].second = val.publicFunds
          this.tableData['top'][4].second = val.allOtherMoney
          this.tableData['top'][2].fifth = val.totalMoneyYear
          this.tableData['top'][3].fourth = val.publicFundsYear
          this.tableData['top'][4].fourth = val.allOtherMoneyYear
          this.tableData['top'][6].first = val.all_target
          this.tableData['top'][6].second = val.year_target
          break
        case 'auditzxzjtype':
          this.tableData['top'][0].second = val.pro_name
          this.tableData['top'][1].second = val.dep_unitname
          this.tableData['top'][2].third = val.amt
          this.tableData['top'][3].second = val.publicFunds
          this.tableData['top'][4].second = val.allOtherMoney
          this.tableData['top'][2].fifth = val.totalMoneyYear
          this.tableData['top'][3].fourth = val.publicFundsYear
          this.tableData['top'][4].fourth = val.allOtherMoneyYear
          this.tableData['top'][6].first = val.all_target
          this.tableData['top'][6].second = val.year_target
          break
        case 'deptjx':
          this.tableData['top'][0].second = val.dep_unitnoname
          this.tableData['top'][1].second = val.mof_dep_name
          break
        default:
          let topDataMap = this.columnConfig.topDataMap || {}
          Object.keys(topDataMap).forEach((key) => {
            let keyMapArr = key.split('__')
            this.$set(this.tableData['top'], keyMapArr[0], this.tableData['top'][keyMapArr[0]] || {})
            this.$set(this.tableData['top'][keyMapArr[0]], keyMapArr[1], val[topDataMap[key].field])
            // self.tableData['top'][keyMapArr[0]] = self.tableData['top'][keyMapArr[0]] || {}
            // self.tableData['top'][keyMapArr[0]][keyMapArr[1]] = val[topDataMap[key].field]
          })
          break
      }
    },
    jsonStringify(columns) {
      // 对象转换成json字符串
      return JSON.stringify(columns, function (key, val) {
        if (typeof val === 'function') {
          return val + ''
        }
        return val
      })
    },
    jsonParse(str) {
      // json字符串转换成对象
      return JSON.parse(str, function (k, v) {
        try {
          if (
            v.indexOf &&
            (v.indexOf('function') > -1 || v.indexOf('=>') > -1)
          ) {
            // return eval('(function(){return ' + v + ' })()')
            // eslint-disable-next-line no-new-func
            let func = new Function('return ' + v)
            return func()
          }
          return v
        } catch (e) {
          return v
        }
      })
    },
    setDatalist(val) { // set data
      if (val) {
        this.formateData(this.deepCopy(val))
      } else {
        this.formateData()
      }
    },
    setTableConfig(tableConfig) { // 设置配置
      //  obj={
      //    top:{},
      //    mid:{},
      //    bottom:{},
      //    topDataMap:{
      //    },
      //  }
      this.columnConfig = tableConfig
      this.formateData()
    },
    setCusTomTableConfig() {
      if (this.crtTableType && tableConfig[this.crtTableType]) {
        this.columnConfig = tableConfig[this.crtTableType]
      } else {
        this.columnConfig = this.customTableConfig
      }
    },
    setAll({ tableConfig, dataList, formChangeData }) { // 设置所有
      if (tableConfig) {
        this.columnConfig = tableConfig
      }
      if (dataList) {
        this.setDatalist(dataList)
      }
      if (formChangeData) {
        this.setFormChangeData(formChangeData)
      }
    }
  },
  created () {
    // this.columnConfig = tableConfig['zxywjf']
  },
  mounted () {
  },
  watch: {
    crtTableType: {
      handler(val) {
        if (this.crtTableType && tableConfig[this.crtTableType]) {
          this.columnConfig = tableConfig[this.crtTableType]
          this.formateData()
        }
      }
    },
    tableData: {
      deep: true,
      handler (val) {
      }
    },
    datalist: {
      handler (val) {
        if (val) {
          this.setCusTomTableConfig()
          this.setDatalist(val)
        }
      },
      immediate: true
    },
    customTableConfig: {
      handler(val) {
        if (val) {
          this.setCusTomTableConfig(val)
        }
      }
    },
    formChangeData: {
      handler (val) {
        if (val) {
          this.setFormChangeData(val)
        }
      },
      deep: true,
      immediate: true
    }
  }
}
</script>
<style lang='scss' scoped>
</style>
