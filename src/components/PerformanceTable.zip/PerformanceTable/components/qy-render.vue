<script>
export default {
  name: 'QyRender',
  functional: true,
  props: {
    scope: {
      type: Object,
      default: () => {}
    },
    render: {
      type: Function,
      default: function() {}
    }
  },
  render: (h, ctx) => {
    return ctx.props.render ? ctx.props.render(h, ctx.props.scope) : ''
  }
}
</script>
