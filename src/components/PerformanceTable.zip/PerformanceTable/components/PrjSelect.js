// 通用类数据
export let publicTypeDataList = [
  {
    id: '1000000000000096310',
    name: '办公场所租赁类'
  },
  {
    id: '1000000000001174312',
    name: '政策研究类'
  },
  {
    id: '1000000000001174313',
    name: '新闻宣传类'
  },
  {
    id: '1000000000001174307',
    name: '基建工程类'
  },
  {
    id: '1000000000000096313',
    name: '大型活动类'
  },
  {
    id: '1000000000001174308',
    name: '科研项目类'
  },
  {
    id: '1000000000001174309',
    name: '信息系统建设运维类'
  },
  {
    id: '1000000000001174310',
    name: '监督检查类'
  },
  {
    id: '1000000000001174311',
    name: '会议培训类'
  },
  {
    id: '1000000000001174316',
    name: '设备购置类'
  },
  {
    id: '1000000000001174317',
    name: '纪检监察类'
  },
  {
    id: '1000000000001174315',
    name: '国际交流合作类'
  },
  {
    id: '1000000000000096306',
    name: '物业管理类'
  },
  {
    id: '1000000000000096308',
    name: '委托咨询类'
  },
  {
    id: '1000000000000096307',
    name: '出国出境类'
  },
  {
    id: '1000000000000096311',
    name: '专项购置类'
  },
  {
    id: '1000000000000096309',
    name: '网络维护建设类'
  },
  {
    id: '1000000000000096312',
    name: '维修改造类'
  },
  {
    id: '1000000000001174314',
    name: '一般公共服务'
  }
]
// 个性类数据
export let projectTypeDataList = [
  {
    id: '75B799607267370CE055000000000001',
    name: '教育'
  },
  {
    id: '75B79960725E370CE055000000000001',
    name: '公共安全'
  },
  {
    id: '75B79960726B370CE055000000000001',
    name: '林业'
  },
  {
    id: '75B79960726E370CE055000000000001',
    name: '交通运输'
  },
  {
    id: '75B799607261370CE055000000000001',
    name: '经济发展'
  },
  {
    id: '75B799607268370CE055000000000001',
    name: '科学技术'
  },
  {
    id: '75B79960725D370CE055000000000001',
    name: '一般公共服务'
  },
  {
    id: '75B799607264370CE055000000000001',
    name: '节能环保'
  },
  {
    id: '75B799607266370CE055000000000001',
    name: '应急管理'
  },
  {
    id: '1000000000001240109',
    name: '粮油物资储备'
  },
  {
    id: '75B799607260370CE055000000000001',
    name: '社会保障和就业'
  },
  {
    id: '75B799607269370CE055000000000001',
    name: '住房与城乡建设'
  },
  {
    id: '1000000000001244009',
    name: '住房保障'
  },
  {
    id: '75B799607265370CE055000000000001',
    name: '卫生健康'
  },
  {
    id: '1000000000001244210',
    name: '资源勘探工业信息等'
  },
  {
    id: '1000000000001245409',
    name: '城乡社区'
  },
  {
    id: '1000000000001245509',
    name: '国防'
  },
  {
    id: '1000000000001245510',
    name: '农林水'
  },
  {
    id: '75B799607263370CE055000000000001',
    name: '自然资源海洋气象等'
  },
  {
    id: '1000000000001075208',
    name: '灾害防治及应急管理'
  },
  {
    id: '75B79960725F370CE055000000000001',
    name: '文体旅游与传媒'
  },
  {
    id: '75B79960726F370CE055000000000001',
    name: '邮政'
  },
  {
    id: '75B79960726D370CE055000000000001',
    name: '水利'
  },
  {
    id: '75B79960726A370CE055000000000001',
    name: '农业农村'
  },
  {
    id: '1000000000000262100',
    name: '市场监督管理'
  }
]
// 指标层级数据
export let IndexHierarchy = [
  {
    id: '1',
    name: '省'
  },
  {
    id: '2',
    name: '市'
  },
  {
    id: '3',
    name: '县区'
  }
]
// 指标适用类型数据
export let IndexTypeDataList = [
  {
    id: '1',
    name: '项目支出评价'
  },
  {
    id: '2',
    name: '部门整体支出评价'
  },
  {
    id: '3',
    name: '财政专项资金评价'
  },
  {
    id: '4',
    name: '政策评价'
  }
]
// 表头
export let jxTableDataItem = [
  {
    title: '一级指标',
    field: 'firstTargetName',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '二级指标',
    field: 'secondTargetName',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '三级指标',
    field: 'indName',
    align: 'left',
    width: '200',
    cellRender: {
      name: 'htmlRender',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '权重',
    field: 'targetWeight',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '评分标准',
    field: 'standardDesc',
    align: 'left',
    width: '200',
    cellRender: {
      name: 'htmlRender',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '指标解释',
    field: 'targetDescription',
    align: 'left',
    width: '200',
    cellRender: {
      name: 'htmlRender',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '指标性质',
    field: 'targetCharacter',
    align: 'left',
    width: '200',
    editRender: {
      name: '$vxeSelect',
      defaultValue: 1,
      options: [
        { value: 1, label: '正向' },
        { value: 2, label: '反向' },
        { value: 3, label: '定性' }
      ]
    }
  },
  {
    title: '目标值',
    field: 'cytValue',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '指标方向',
    field: 'targetDirection',
    align: 'left',
    width: '200',
    editRender: {
      name: '$vxeSelect',
      defaultValue: 1,
      options: [
        { value: 1, label: '大于' },
        { value: 2, label: '大于等于' },
        { value: 3, label: '等于' },
        { value: 4, label: '小于' },
        { value: 5, label: '小于等于' }
      ]
    }
  },
  {
    title: '计量单位',
    field: 'calculation',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '资金用途',
    field: 'zjytText',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  // {
  //   title: '支出功能科目',
  //   field: 'funcCode',
  //   align: 'left',
  //   width: '200',
  //   editRender: {
  //     name: '$input',
  //     props: {
  //       type: 'text'
  //     }
  //   }
  // },
  {
    title: '领域/事项分类',
    field: 'targetCatagory',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  },
  {
    title: '行业分类',
    field: 'targetClassify',
    align: 'left',
    width: '200',
    editRender: {
      name: '$input',
      props: {
        type: 'text'
      }
    }
  }
  // {
  //   title: '核心指标',
  //   field: 'targetClassify',
  //   align: 'left',
  //   width: '200',
  //   editRender: {
  //     name: '$input',
  //     props: {
  //       type: 'text'
  //     }
  //   }
  // },
  // {
  //   title: '项目类型',
  //   field: 'target_character',
  //   align: 'left',
  //   width: '200',
  //   editRender: {
  //     name: '$input',
  //     props: {
  //       type: 'text'
  //     }
  //   }
  // }
]
// 表数据
export let jxTableDataList = {
  ind_code: '',
  zjyt: '',
  second_target_name: '',
  ind_name: '',
  standard_value: '',
  act_value: '',
  history_value: '',
  reference_value: '',
  target_suitable_level: '',
  target_suitable_type: '',
  target_new_type: '',
  project_type: ''
}
// 表格右侧按钮
export let btnconfig = {
  buttonConfOne: { // table工具栏配置(未处理)
    moneyConversion: false,
    buttons: [
      { code: 'toolbar-sure', name: '确定挑选项目', status: 'primary' },
      { code: 'toolbar-faile', name: '取消' }
    ]
  }
}
