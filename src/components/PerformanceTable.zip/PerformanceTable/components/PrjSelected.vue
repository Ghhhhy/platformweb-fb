<template>
  <div class="prjSelected">
    <el-dialog
      v-loading="showTableJxData"
      :visible.sync="showDialog"
      width="92%"
      title="指标库"
      center
      z-index-5
      @close="closePrj"
    >
      <div v-show="isShowQueryConditions" class="content-query">
        <BsQuery
          ref="queryForm"
          :query-form-item-config="queryFormItemConfig"
          :query-form-data="queryFormData"
          @onSearchClick="searchData"
          @onSearchResetClick="resetData"
          @itemChange="itemChange"
        />
      </div>
      <div class="content-table">
        <BsTable
          ref="jxTable"
          :table-config="tableConfig"
          :toolbar-config="toolbarConfig"
          :table-columns-config="jxTableDataItem"
          :table-data="jxTableDataList"
          :pager-config="mainPagerConfig"
          :edit-config="false"
          @ajaxData="ajaxTableData"
        />
      </div>
    </el-dialog>
  </div>
</template>
<script>
// <div class="content flex">
//         <div class="content-title flex">
//           <label class="label">一级指标</label>
//           <el-select v-model="queryAll" class="">
//             <el-option v-for="it in firstLevelData" :key="it.id" :label="it.name" :value="it.id" />
//           </el-select>
//         </div>
//         <div class="content-title flex">
//           <label class="label">二级指标</label>
//           <el-select v-model="publicType" class="">
//             <el-option v-for="it in secondLevelData" :key="it.id" :label="it.name" :value="it.id" />
//           </el-select>
//         </div>
//         <div class="content-title flex">
//           <label class="label">三级指标</label>
//           <el-select v-model="projectType" class="">
//             <el-option v-for="it in thirdLevelData" :key="it.id" :label="it.name" :value="it.id" />
//           </el-select>
//         </div>
//         <div class="content-title flex">
//           <label class="label">关键字</label>
//           <el-input v-model="searchKey" />
//         </div>
//         <div class="content-btn">
//           <el-button @click="searchData">搜索</el-button>
//           <el-button @click="resetData">重置</el-button>
//         </div>
//       </div>
import jxUrl from '@/api/frame/main/projectLib/projectDeclarationManage/ProjectReport.js'
// import config from '../config.js'
import { btnconfig, publicTypeDataList, projectTypeDataList, IndexHierarchy, IndexTypeDataList, jxTableDataItem, jxTableDataList } from './PrjSelect.js'
export default {
  name: 'PrjSelected',
  props: {
    targetname: { // 二级指标对象
      type: Object,
      default: () => {
        return {}
      }
    },
    unitdata: {
      type: String,
      default: () => {
        return ''
      }
    },
    firstIndId: {
      type: String,
      default: () => {
        return ''
      }
    },
    secondIndId: {
      type: String,
      default: () => {
        return ''
      }
    },
    threeLevelData: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      firstLevelData: [],
      secondLevelData: [],
      thirdLevelData: [],
      showTableJxData: false,
      showDialog: true,
      queryAll: '',
      isShowQueryConditions: true,
      queryFormItemConfig: [
        {
          field: 'indName',
          title: '三级指标',
          span: 4,
          itemRender: {
            name: '$vxeInput',
            props: {
              type: 'string',
              clearable: true,
              placeholder: '三级指标'
            }
          }
        },
        {
          field: 'searchKey',
          title: '关键字',
          span: 4,
          itemRender: {
            name: '$vxeInput',
            props: {
              type: 'string',
              clearable: true,
              placeholder: '关键字'
            }
          }
        },
        // {
        //   field: 'func',
        //   title: '资金功能科目',
        //   span: 4,
        //   itemRender: {
        //     name: '$vxeTree',
        //     props: {
        //       config: {
        //         multiple: false,
        //         isHump: true,
        //         placeholder: '请选择资金功能科目',
        //         treeProps: {
        //           // 树配置选项
        //           labelFormat: '{code}-{name}', // {code}-{name}
        //           nodeKey: 'id', // 树的主键
        //           label: 'name', // 树的显示lalel字段
        //           children: 'children' // 树的嵌套字段
        //         },
        //         axiosConfig: {
        //           successCode: '100000', // 成功code
        //           statusField: 'code',
        //           method: 'get', // 请求方式
        //           url: 'bisBasicinfo/basicinfo/comm/queryCommTree' // 'queryTreeAssistData', // 是否调用接口直接获取数据，当此项有值时将会自动家数据
        //         },
        //         isleaf: true
        //       },
        //       queryparams: {
        //         eleCode: 'VW_BAS_EXP_FUNC'
        //       }
        //     }
        //   }
        // },
        {
          field: 'targetCatagory',
          title: '行业领域',
          span: 4,
          itemRender: {
            name: '$vxeSelect',
            options: [],
            props: {
              placeholder: '行业领域'
            }
          }
        },
        {
          field: 'targetClassify',
          title: '行业分类',
          span: 4,
          itemRender: {
            name: '$vxeSelect',
            options: [],
            props: {
              placeholder: '行业分类'
            }
          }
        },
        {
          field: 'zjytText',
          title: '资金用途',
          span: 4,
          itemRender: {
            name: '$vxeSelect',
            options: [],
            props: {
              placeholder: '资金用途'
            }
          }
        }
      ],
      queryFormData: {
        indName: '', // 三级指标
        searchKey: '', // 关键字
        zjytText: '', // 资金用途
        funcCode: '', // 支出科目
        targetCatagory: '', // 行业领域
        targetClassify: '' // 行业分类
      },
      publicType: '',
      projectType: '',
      searchKey: '',
      indexType: '',
      publicTypeDataList,
      projectTypeDataList,
      IndexHierarchy,
      IndexTypeDataList,
      jxTableDataItem,
      jxTableDataList,
      mainPagerConfig: {
        total: 0,
        currentPage: 1,
        pageSize: 20
      },
      params: {
        searchKey: '',
        target_new_type: '',
        project_type: '',
        target_suitable_level: '',
        target_suitable_type: '',
        second_target_name: '',
        districtId: '',
        // agencycode: data.orgcode,
        agencycode: '703004001',
        pageInfo: {
          pageSize: '',
          offset: ''
        }
      },
      tableConfig: {
        methods: {
          toolbarButtonClickEvent: this.toolbarButtonClickEvent
        },
        renderers: {
          htmlRender: {
            renderDefault(h, cellRender, params, context) {
              let { row, column } = params
              return [
                h('span', {
                  domProps: {
                    innerHTML: row[column.property]
                  }
                })
              ]
            }
          }
        }
      },
      toolbarConfig: btnconfig.buttonConfOne
    }
  },
  created () {
    this.getCatagoryList()
  },
  mounted() {
    this.searchData()
    // this.getFirstLevelData()
    // this.getSecondLevelData()
    // this.getThirdLevelData()
  },
  methods: {
    // getFirstLevelData() {
    //   let firstJxData = []
    //   jxUrl.getFirstLevelData().then(res => {
    //     if (res.code === 0) {
    //       res.content.forEach(item => {
    //         firstJxData.push({ id: item.indId, name: item.indName })
    //       })
    //     } else {
    //       this.$message.error('获取一级指标失败: ' + res.result)
    //     }
    //     this.firstLevelData = Object.assign([], firstJxData)
    //   }).catch(err => {
    //     console.log(err)
    //   })
    // },
    // getSecondLevelData() {
    //   let secondJxData = []
    //   let params = { parentId: '' }
    //   jxUrl.getSecondLevelData(params).then(res => {
    //     if (res.code === 0) {
    //       res.content.forEach(item => {
    //         secondJxData.push({ id: item.indId, name: item.indName })
    //       })
    //     } else {
    //       this.$message.error('获取二级指标失败: ' + res.result)
    //     }
    //     this.secondLevelData = Object.assign([], secondJxData)
    //   }).catch(err => {
    //     console.log(err)
    //   })
    // },
    // getThirdLevelData() {
    //   let thirdJxData = []
    //   let params = { firstTarget: '', secondTarget: '', searchKey: '', usedType: 1, currpage: 1, limit: 20 }
    //   jxUrl.getPrjLibIndex(params).then(res => {
    //     if (res.code === 0) {
    //       res.content.forEach(item => {
    //         thirdJxData.push({ id: item.indId, name: item.indName })
    //       })
    //     } else {
    //       this.$message.error('获取三级指标失败: ' + res.result)
    //     }
    //     this.thirdLevelData = Object.assign([], thirdJxData)
    //   }).catch(err => {
    //     console.log(err)
    //   })
    // },
    itemChange(obj, form) {
      debugger
      let self = this
      if (obj.property === 'targetCatagory') {
        obj.data.targetClassify = ''
        obj.data.zjytText = ''
        self.getClassifyList(obj.itemValue, 'targetClassify')
      }
      if (obj.property === 'targetClassify') {
        obj.data.zjytText = ''
        self.getClassifyList(obj.itemValue, 'zjytText')
      }
    },
    // 关闭
    closePrj() {
      this.showDialog = false
      this.$parent.showPrjSelected = false
    },
    // 重置
    resetData() {
      this.queryFormData = {
        indName: '',
        searchKey: '',
        zjytText: '',
        funcCode: '',
        targetCatagory: '',
        targetClassify: ''
      }
      this.searchData()
    },
    // 搜索调绩效接口
    searchData(data) {
      let param = {}
      param.firstTarget = this.firstIndId
      param.secondTarget = this.secondIndId
      param.usedType = '1'
      param.currpage = this.mainPagerConfig.currentPage
      param.limit = this.mainPagerConfig.pageSize
      if (data) {
        param.indName = data.indName
        param.searchKey = data.searchKey
        param.zjyt = data.zjytText
        param.funcCode = data.funcCode
        param.tradeStandardValue = data.targetCatagory
        param.targetCatagory = data.targetClassify
      }

      // this.showTableJxData = true

      jxUrl.getPrjLibIndex(param).then(res => {
        if (res.code === 0) {
          this.jxTableDataList = res.content.records
          this.mainPagerConfig.total = res.content.total
          this.showTableJxData = false
        } else {
          this.showTableJxData = false
        }
      }).catch(err => {
        console.log(err)
        this.showTableJxData = false
      })

      // let res = config['threeData']
      // if (res.code === 0) {
      //   this.jxTableDataList = res.content.records
      //   this.mainPagerConfig.total = res.content.total
      //   this.showTableJxData = false
      // } else {
      //   this.showTableJxData = false
      // }
    },
    // 点击右侧按钮执行的操作方法
    toolbarButtonClickEvent(obj, context, e) {
      switch (obj.code) {
        case 'toolbar-sure': // 确定挑选项目
          this.listenClick(obj, context, e)
          break
        case 'toolbar-faile': // 取消
          this.closePrj(obj, context, e)
          break
        default:
      }
    },
    listenClick(obj, self, e) {
      let flage = this.validation(self.selection)
      if (flage) {
        this.showDialog = false
        self.selection.forEach(element => {
          element.targetCharacter = element.targetCharacter ? Number(element.targetCharacter) : ''
          element.targetDirection = element.targetDirection ? Number(element.targetDirection) : ''
          element.indName = element.indName ? element.indName.replace(/<[^>]+>/g, '') : ''
          element.standardDesc = element.standardDesc ? element.standardDesc.replace(/<[^>]*>/g, '') : ''
          element.targetDescription = element.targetDescription ? element.targetDescription.replace(/<[^>]*>/g, '') : ''
        })
        this.$emit('threeDataObj', self.selection)
      }
    },
    validation(selectionData) {
      let flage = true
      if (selectionData.length === 0) {
        this.$message.error('请选择一条指标数据!')
        flage = false
      }
      selectionData.forEach(element => {
        this.threeLevelData.forEach(item => {
          if (element.indId === item.indId) {
            this.$message.error('指标【' + item.indName + '】已被使用')
            flage = false
          }
        })
      })
      return flage
    },
    // 表格分页
    ajaxTableData({ params, currentPage, pageSize }) {
      this.mainPagerConfig.currentPage = currentPage
      this.mainPagerConfig.pageSize = pageSize
      this.params.pageInfo.pageSize = this.mainPagerConfig.pageSize
      this.params.pageInfo.offset = this.mainPagerConfig.currentPage
      this.searchData()
    },
    getCatagoryList() {
      jxUrl.getCatagoryList().then(res => {
        if (res.code === 0) {
          let newData = []
          let data = res.content
          data.forEach(map => {
            let newMap = {}
            newMap['value'] = map.id
            newMap['label'] = map.name
            newData.push(newMap)
          })
          this.queryFormItemConfig.forEach(item => {
            if (item.field === 'targetCatagory') {
              item.itemRender.options = newData
            }
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    getClassifyList(superguid, fieldName) {
      jxUrl.getClassifyList({ 'superguid': superguid }).then(res => {
        if (res.code === 0) {
          let newData = []
          let data = res.content
          data.forEach(map => {
            let newMap = {}
            newMap['value'] = map.id
            newMap['label'] = map.name
            newData.push(newMap)
          })
          this.queryFormItemConfig.forEach(item => {
            if (item.field === fieldName) {
              item.itemRender.options = newData
            }
          })
        }
      }).catch(err => {
        console.log(err)
      })
    }
  },
  watch: {
    targetname: {
      handler(newValue, oldValue) {
      },
      deep: true,
      immediate: true
    }
  }
}
</script>
<style lang="scss">
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.prjSelected {
  .el-dialog {
    height: 80%;
    overflow: auto;
    .content {
      width: 100%;
      .content-title {
        height: 50px;
        // margin-left: 30px;
        justify-content: space-between;
        align-items: center;
        .label {
          width: 125px;
          text-align: right;
          margin-right: 10px;
        }
        .el-scrollbar .el-scrollbar__view .el-select-dropdown__item {
          padding: 5px;
        }
      }
      .content-btn {
        width: 20%;
        height: 50px;
        line-height: 50px;
        text-align: right;
        margin-right: 10px;
      }
    }
    .content-table {
      height: 68vh;
    }
    .content-query {
      height: 7vh;
    }
  }
}
</style>
