### 绩效组件使用文档

#### 使用
引入：
```js
import qyTable from '@/components/PerformanceTable'

```
```html
<qy-table
  ref="table"
  :crt-table-type="'zxywjf'"
  :datalist="datalist"
  :type="'read'"
  :form-change-data="formChangeData"
/>
```
参数解释：
```js
crtTableType: String = 'zxywjf' || 'zxzj' || 'bmzt' || 'rygz', // 当前模板
datalist: Object = {}, // 当前组件回显数据，组件类型为‘read’时必须
type: String = 'read' || 'create', // 当前组件类型 回显或新建
formChangeData: Object // 修改当前组件某项的值。 this.$set(this.formChangeData, 'pro_name', Math.random() + 1)

// 方法
// 数据保存，当前组件的值以回调的形式传回
this.$refs.table.saveData(data => {
  console.log(data, 'data')
})
```
参数配置：
配置相关模板时，在config文件中对应类型配置top、bottom默认数据。
top: 
  1、thHead: 分为'text'和'btns'类型，text类型用于表格标题，btns用于按钮组操作。
  2、thList: 可隐藏，必需。 设置column，prop、label(可选)、childrenProp(input: Array = [], 设置为input的行； disabledRows: Array = [], 渲染为disabled的行; textAreaRows:Array = [], 渲染为disabled的行)
  3、mergeMethod: String = 'fieldMerge' || 'indexMerge'。 合并行列的方法。 fieldMerge以字段合并，indexMerge以设置的数组进行合并。 e.p [1, 0, 1, 2], // 列数，行数 rowSpan， colspan。

bottom:
  activeCol: String = 'second'。 设置高亮的列。
  noteProp: 备注设置。
  defaultInputCol: Array = []。 type为‘create’时默认input的列。
  defaultTopData: Array = []   设置默认数据。

！！！调用时需要在组件中做出的调整：
当前组件是将接口返回的对象数据转换成为table数据， 保存时再将table数据转换成对象数据。 故而在使用过程中需要多处进行数据转换处理。 
PerformanceTable/index.vue中：
  展示时formTopData方法中在相应switch case 配置对应数据调整， watch-formChangeData中调整相应数据。  
  保存时需要在saveData方法中对应case 拼凑需要的参数。 

### 组件底层

组件基于element，是将element-table的二次封装。 因数据展示格式不同，表格合并规则不同，故而将绩效各模板分为top(类excel表)+bottom(类table表) + 外部指标库挑选组件。

有任何问题请联系 前端-向挺。










