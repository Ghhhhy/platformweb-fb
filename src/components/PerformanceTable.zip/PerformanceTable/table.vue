/*
 * @Author: 轻语
 * @Date: 2021-01-29 09:33:59
 * @Last Modified by: 轻语
 * @Last Modified time: 2021-02-01 16:21:47
 */

<template>
  <div class="" style="width: 100%">
    <el-table
      ref="elTable"
      :style="tableConfig.style"
      :data="
        tableConfig.noteProp && tableConfig.noteProp.isShowNote
          ? form.concat([noteObj])
          : form
      "
      border
      :cell-style="finalCellStyle"
      :header-row-class-name="tableRowClassName"
      :span-method="mergeMethod"
      @cell-click="cellClick"
    >
      <QyColumn
        v-for="(item, index) in tableData.column"
        :key="index"
        v-bind="$attrs"
        :column="item"
      />
    </el-table>
  </div>
</template>

<script>
// import configData from './config.js'
import QyColumn from './components/qy-column'
// import pushData from './push.json'
// 绩效路由
import getCase from '@/api/frame/main/projectLib/projectDeclarationManage/ProjectReport.js'
import ToolFn from '@/components/tool/util.js'
import Store from '@/utils/store'

export default {
  components: { QyColumn },
  props: {
    tableConfig: {
      type: Object,
      default: () => {
        return {}
      }
    },
    dataObj: {
      type: [Object, Array],
      default: () => { }
    },
    type: {
      type: String,
      default: 'read'
    }
  },
  data () {
    return {
      inputText: '',
      currentRow: {},
      currentCol: {},
      deleteRow: {},
      mergeIndex: {},
      form: [],
      tableData: {},
      hideHeaderRowIndex: null,
      pushList: [],
      pushListcp: [],
      // 新增指标性质与指标方向下拉选项
      budgtTypeOption: [],
      budgtDirectionOption: []
    }
  },
  computed: {
    activeCol () {
      return (this.tableConfig && this.tableConfig.activeCol) || []
    },
    mergeMethod () {
      return ((this.tableConfig && this.tableConfig.mergeMethod.type === 'fieldMerge')
        ? this.fieldMerge
        : this.indexMerge) || []
    },
    noteObj () {
      // 如有备注配置，则push一条数据
      const { noteField, noteValue } = (this.tableConfig && this.tableConfig.noteProp) || {}
      return {
        [noteField || 'mark']: noteValue || ''
      }
    }

  },
  methods: {
    ...ToolFn.transformFn,
    ...ToolFn.utilFn,
    // 单元格点击
    input(e) {
      this.inputText = e
      let newFilterList = []
      if (e !== '') {
        this.pushList.filter(item => {
          if (item.proName.indexOf(this.inputText) !== -1) {
            newFilterList.push(item)
          }
        })
        this.pushListcp = newFilterList
      } else {
        this.pushListcp = this.pushList
      }
    },
    cellClick (row, column, cell, event) {
      this.deleteRow = row
      if (column.property === this.activeCol) {
        this.currentCol = column
        this.currentRow = row
        this.$emit('currentRow', row)
        // 获取当前单元格所有子节点
        this.formateCrtCellChild(row)
      }
    },
    // 通过activeCol属性 将其放入父级subArr属性中
    formateCrtCellChild (row) {
      const arr = this.form.filter(item => {
        return item[this.activeCol] === row[this.activeCol]
      })
      this.currentRow.subArr = JSON.parse(JSON.stringify(arr))
    },
    // 单元格class
    finalCellStyle ({ row, column, rowIndex, columnIndex }) {
      row.rowIndex = rowIndex
      column.columnIndex = columnIndex
      if (this.currentRow.index === row.index && column.property === this.activeCol
      ) {
        return 'background: pink !important;'
      }
    },
    // 通过字段合并
    fieldMerge ({ row, column, rowIndex, columnIndex }) {
      const { value } = this.tableConfig.mergeMethod
      const index = value.indexOf(column.property)
      if (index > -1) {
        const _row = this.mergeIndex[value[index]][rowIndex]
        const _col = _row > 0 ? 1 : 0
        return {
          rowspan: _row,
          colspan: _col
        }
      }
      // 备注行合并
      if (this.tableConfig.noteProp && this.tableConfig.noteProp.isShowNote) {
        if (rowIndex === this.form.length) {
          return [1, this.tableConfig.thList.data.length]
        }
      }
    },
    // 通过既定参数强行合并
    indexMerge ({ row, column, rowIndex, columnIndex }) {
      let { value } = this.tableConfig.mergeMethod
      value = value.filter(item => {
        return item[0] === columnIndex && item[1] === rowIndex
      })[0]
      if (value) {
        return [value[2], value[3]]
      }
      // 备注行合并
      if (this.tableConfig.noteProp && this.tableConfig.noteProp.isShowNote) {
        if (rowIndex === this.form.length) {
          return [1, this.tableConfig.thList.data.length]
        }
      }
    },
    // 表头样式调整
    tableRowClassName ({ row, rowIndex }) {
      if (rowIndex === this.hideHeaderRowIndex - 1) {
        return 'hidden'
      }
    },
    // 按字段合并行列
    getMergeArr (tableData, merge) {
      if (!merge) return
      const mergeLine = {}
      this.mergeIndex = {}
      merge.forEach((item, k) => {
        tableData.forEach((data, i) => {
          if (i === 0) {
            this.mergeIndex[item] = this.mergeIndex[item] || []
            this.mergeIndex[item].push(1)
            mergeLine[item] = 0
          } else {
            if (data[item] === tableData[i - 1][item]) {
              this.mergeIndex[item][mergeLine[item]] += 1
              this.mergeIndex[item].push(0)
            } else {
              this.mergeIndex[item].push(1)
              mergeLine[item] = i
            }
          }
        })
      })
    },
    // 渲染表头
    renderTh () {
      const { thHead, thList } = this.tableConfig
      let obj = {}
      let self = this
      // 文本类型
      if (thHead && Object.keys(thHead).length) {
        if (thHead.type === 'text') {
          obj.renderHeader = (h, scope) => {
            return <div>
              {thHead.values.map(el => {
                return (
                  <el.el style={el.style} >{el.text}</el.el>
                )
              })}
            </div>
          }
          // btn类型
        } else if (thHead.type === 'btns') {
          const disabled = this.type === 'read'
          if (!disabled) {
            obj.renderHeader = (h, scope) => {
              return <div style={thHead.style} >
                {thHead.values.map(el => {
                  return (
                    !el.isTooltip
                      ? <el-button
                        type={el.type}
                        size={el.size || 'mini'}
                        nativeOnClick={() => this.handToBtn(el.case)}
                        style={el.style}
                        disabled={disabled}
                      >{el.text}
                      </el-button>
                      : <el-dropdown style="margin: 0 10px" trigger="click">
                        <el-button
                          type={el.type}
                          size={el.size || 'mini'}
                          nativeOnClick={() => this.handToBtn(el.case)}
                          style={el.style}
                          disabled={disabled}>{el.text}
                        </el-button>
                        <el-dropdown-menu slot="dropdown" style="margin: 0 10px;overflow: auto !important;height: 60%;">
                          <div>
                            <span><el-input type="text" value={this.inputText} onInput={this.input} placeholder='请输入搜索内容' style="width:90%; margin:0 5%"/></span>
                          </div>
                          {
                            this.pushListcp.map(item => {
                              return (
                                <el-dropdown-item
                                  nativeOnClick={() => this.choosePushData(item.caseId)}
                                >{item.proName}</el-dropdown-item>
                              )
                            })
                          }
                        </el-dropdown-menu>
                      </el-dropdown>
                  )
                })}
              </div>
            }
          }
        }
        // 是否隐藏表头th  以thHead为rowIndex
        if (thList.hidden) {
          this.hideHeaderRowIndex = thHead.values.length
        }
        // let length = 9
        // if (self.$refs.elTable && self.$refs.elTable.data) {
        //   length = self.$refs.elTable.data.length + 1
        // }
        obj.children = thList.data.map(item => {
          const defaultChildrenProp = {
            inputRows: [], // 渲染为input框的行
            disabledRows: [], // 渲染为disabled的行
            textAreaRows: [],
            selectRows: [],
            moneyRows: []
          }
          item.childrenProp = { ...defaultChildrenProp, ...item.childrenProp }
          // 根据defaultInputCol 将其列的所有行都设为input
          if (self.tableConfig.defaultInputCol && self.tableConfig.defaultInputCol.includes(item.prop)) {
            item.childrenProp.inputRows = Array.from({ length: 1000 }, (v, k) => k)
          }
          if (self.tableConfig.defaultSelectCol && self.tableConfig.defaultSelectCol.includes(item.prop)) {
            item.childrenProp.selectRows = Array.from({ length: 1000 }, (v, k) => k)
          }

          // 处理备注行
          // if (self.tableConfig.noteProp && self.tableConfig.noteProp.isShowNote && item.prop === self.tableConfig.noteProp.noteField) {
          //   // 行类型设置为固定行生效，若需要保证最后一行为特殊类型，则需要反复移除之前行数，并添加最新行数。
          //   if (item.childrenProp.inputRows.includes(self.form.length - 1)) {
          //     item.childrenProp.inputRows.pop()
          //   } else {
          //     const index = item.childrenProp.inputRows.sort((a, b) => a - b).findIndex(i => i > self.form.length - 1)
          //     if (index !== -1) {
          //       // item.childrenProp.inputRows.splice(index, item.childrenProp.inputRows.length - index)
          //     }
          //   }
          //   // item.childrenProp.inputRows.push(this.form.length)
          //   // item.childrenProp.textAreaRows.push(this.form.length)
          //   // this.tableConfig.noteProp.disabled && item.childrenProp.disabledRows.push(this.form.length)
          // }
          return {
            ...item,
            render: (h, scope) => {
              let divData
              if (this.type === 'read') {
                divData = item.childrenProp.inputRows.includes(scope.row.rowIndex)
                  ? this.renderInput(scope, item.childrenProp.disabledRows, item.childrenProp.textAreaRows, true)
                  : item.childrenProp.selectRows.includes(scope.row.rowIndex)
                    ? this.renderSelect(scope, item.childrenProp.disabledRows, item, true)
                    : item.childrenProp.moneyRows.includes(scope.row.rowIndex)
                      ? this.renderMoney(scope, item.childrenProp.disabledRows, item, true)
                      : this.renderText(scope, item)
              } else {
                divData = item.childrenProp.inputRows.includes(scope.row.rowIndex)
                  ? this.renderInput(scope, item.childrenProp.disabledRows, item.childrenProp.textAreaRows, false)
                  : item.childrenProp.selectRows.includes(scope.row.rowIndex)
                    ? this.renderSelect(scope, item.childrenProp.disabledRows, item, false)
                    : item.childrenProp.moneyRows.includes(scope.row.rowIndex)
                      ? this.renderMoney(scope, item.childrenProp.disabledRows, item, false)
                      : this.renderText(scope, item)
              }
              return (
                <div>
                  {divData}
                </div>
              )
            }
          }
        })
      }
      this.tableData.column = [obj]
    },
    // renderMoney(scope, item) {
    //   let value = scope.row[scope.column.property] / 10000
    //   return (
    //     <vxe-input
    //       value={value}
    //       clearable
    //       onChange={({ value }) => {
    //         scope.row[scope.column.property] = value * 10000
    //       }}
    //     ></vxe-input>
    //   )
    // },
    renderMoney (scope, disabledRows, item, isRead) {
      let disabled = disabledRows.includes(scope.row.rowIndex)
      let value = scope.row[scope.column.property] ? this.$ToolFn.transformFn.accurateChuFa(scope.row[scope.column.property], 10000) : 0
      // let value = scope.row[scope.column.property] ? scope.row[scope.column.property] / 10000 : 0
      return (
        <el-input
          class="input-box"
          size="mini"
          value={value}
          disabled={isRead ? true : disabled}
          onInput={(val) => {
            scope.row[scope.column.property] = this.$ToolFn.transformFn.accurateChengFa(val, 10000)
            this.form[scope.$index] = scope.row
            this.$emit('update:dataObj', this.form)
          }}
        ></el-input>
      )
    },
    renderSelect(scope, disabledRows, item, isRead) {
      let selectData = []
      let disabled = disabledRows.includes(scope.row.rowIndex)
      if (item.prop === 'targetCharacter') {
        selectData = this.budgtDirectionOption
        selectData.map(element => {
          element['value'] = Number(element['value'])
        })
        // selectData = [{ label: '正向', value: 1 }, { label: '反向', value: 2 }, { label: '定性', value: 3 }]
      }
      if (item.prop === 'fourth') {
        selectData = this.budgtTypeOption
        selectData.map(element => {
          element['value'] = Number(element['value'])
        })
        // selectData = [{ label: '大于', value: 1 }, { label: '大于等于', value: 2 }, { label: '等于', value: 3 }, { label: '小于', value: 4 }, { label: '小于等于', value: 5 }]
      }
      return (
        <vxe-select
          value={scope.row[scope.column.property]}
          style="width: 120px"
          transfer={true}
          onChange={({ value }) => {
            value = this.inputCheckItemSelect(value, scope)
            scope.row[scope.column.property] = value
            this.form[scope.$index] = scope.row
            this.$emit('update:dataObj', this.form)
          }}
          clearable
          disabled={isRead ? true : disabled}
        >
          {selectData.map((itemp, indexp) => {
            return <vxe-option value={itemp.value} label={itemp.label} visible={true} />
          })}
        </vxe-select>
      )
    },
    // 渲染input框
    renderInput (scope, disabledRows, textAreaRows, isRead) {
      let disabled = disabledRows.includes(scope.row.rowIndex)
      let type = textAreaRows.includes(scope.row.rowIndex) ? 'textarea' : 'text'
      return (
        <el-input
          class="input-box"
          size="mini"
          value={scope.row[scope.column.property]}
          onInput={(val) => {
            val = this.inputCheckItemInput(val, scope)
            scope.row[scope.column.property] = val
            this.form[scope.$index] = scope.row
            this.$emit('update:dataObj', this.form)
          }}
          disabled={isRead ? true : disabled}
          type={type}
        ></el-input>
      )
    },
    renderText (scope, item) {
      return (
        <div>
          { scope.row[scope.column.property]}
        </div>
      )
    },
    // // 黑龙江地区下拉框选择校验
    // inputCheckItemSelectHlj (val, scope) {
    //   let columnName = scope.column.property
    //   // 指标性质选择
    //   // 获取到当前行目标值列表头对象
    //   let columnSixthObj = scope._self.tableConfig.thList.data.find(item => item.prop === 'sixth')
    //   // 清除当前列禁止修改
    //   columnSixthObj.childrenProp.disabledRows = columnSixthObj.childrenProp.disabledRows.filter(item => item !== scope.$index)
    //   if (columnName === 'fourth' && val === 6) {
    //     // 指标性质选择为定性时，计量单位赋值默认值
    //     scope.row.sixth = '/'
    //     // 指标方向默认为正向
    //     scope.row.targetCharacter = 1
    //     // 指标性质选择定性时，目标值项禁用
    //     columnSixthObj.childrenProp.disabledRows.push(scope.$index)
    //   } else if (columnName === 'fourth' && val !== 6) {
    //     // 指标性质选择为非定性时，即选择了大于小于等于，目标值只能输入数字
    //     debugger
    //     this.$ToolFn.validateFn.rule.isNumber(scope.row.fifth) ? scope.row.fifth = Number(scope.row.fifth) : scope.row.fifth = null
    //     if (val === 1 || val === 2 || val === 3) {
    //       //  若指标性质选择了大于、大于等于、等于，指标方向默认为正向
    //       scope.row.targetCharacter = 1
    //     } else {
    //       //  若指标性质选择了小于、小于等于，指标方向默认为反向
    //       scope.row.targetCharacter = 2
    //     }
    //   } else {
    //   }
    //   // 指标方向选择为正向或者反向时，目标值只能输入数字
    //   if (columnName === 'targetCharacter' && (val === 1 || val === 2)) {
    //     this.$ToolFn.validateFn.rule.isNumber(scope.row.fifth) ? scope.row.fifth = Number(scope.row.fifth) : scope.row.fifth = null
    //   }
    //   return val
    // },
    // // 黑龙江地区输入框输入数字校验
    // inputCheckItemNumberHlj (val, scope) {
    //   // 指标性质选择为非定性时，即选择了大于小于等于，目标值只能输入数字
    //   if ((scope.row.fourth && scope.row.fourth !== 6) && scope.column.property === 'fifth') {
    //     this.$ToolFn.validateFn.rule.isNumber(val) ? val = Number(val) : val = null
    //   }
    //   // 指标方向选择为正向或者反向时，目标值只能输入数字
    //   if ((scope.row.targetCharacter && (scope.row.targetCharacter === 1 || scope.row.targetCharacter === 2)) && scope.column.property === 'fifth') {
    //     this.$ToolFn.validateFn.rule.isNumber(val) ? val = Number(val) : val = null
    //   }
    //   return val
    // },
    // 产品下拉框选择校验
    inputCheckItemSelect (val, scope) {
      let columnName = scope.column.property
      // 指标性质选择
      // 获取到当前行指标方向列表头对象
      let columnFourthObj = scope._self.tableConfig.thList.data.find(item => item.prop === 'fourth')
      // 清除当前列禁止修改
      columnFourthObj.childrenProp.disabledRows = columnFourthObj.childrenProp.disabledRows.filter(item => item !== scope.$index)
      // 获取到当前行目标值列表头对象
      let columnSixthObj = scope._self.tableConfig.thList.data.find(item => item.prop === 'sixth')
      // 清除当前列禁止修改
      columnSixthObj.childrenProp.disabledRows = columnSixthObj.childrenProp.disabledRows.filter(item => item !== scope.$index)
      if (columnName === 'targetCharacter' && (val === 3 || val === '3')) {
        // 指标性质选择为定性时，指标方向、计量单位赋值默认值
        scope.row.fourth = ''
        scope.row.sixth = ''
        // 指标性质选择定性时，指标方向、计量单位禁用
        columnFourthObj.childrenProp.disabledRows.push(scope.$index)
        columnSixthObj.childrenProp.disabledRows.push(scope.$index)
      }
      return val
    },
    // 产品输入框输入校验
    inputCheckItemInput (val, scope) {
      // 三级指标名称限制输入中文
      if (scope.column.property === 'third' && scope.column.label === '三级指标名称' && !this.checkChinese(val)) {
        this.$message({ message: '三级指标名称只能输入中文', type: 'warning' })
        return null
      }
      return val
    },
    checkChinese(str) {
      var reg = /^[\u4E00-\u9FA5]+$/
      if (reg.test(str)) {
        return true
      } else {
        return false
      }
    },
    // 案例推送选择
    choosePushData (id) {
      let params = {
        'caseId': id // id
      }
      getCase.getProCaseDetail(params).then(res => {
        if (res.code === 0) {
          let allData = {}
          let baseInfo = res.content.viewData.baseInfo
          baseInfo.pushAllTarget = baseInfo['pm_perf_goal_case_info$ALL_TARGET']
          let data = res.content.viewData.targetTree.pm_perf_case_indicator
          let newData = []
          data.forEach(map => {
            let newMap = {}
            for (var key in map) {
              let newKey = this.toCamel(key.replace('pm_perf_case_indicator$', '').toLowerCase())
              newMap[newKey] = map[key]
            }
            newMap['id'] = map['pm_perf_case_indicator$IND_CODE']
            newMap['gtId'] = map['pm_perf_case_indicator$IND_CODE']
            if (map['pm_perf_case_indicator$LEVEL_NO'] === 3) {
              newMap['parentid'] = map['pm_perf_case_indicator$IND_CODE'].trim().substr(0, 8)
              newMap['parentGtId'] = map['pm_perf_case_indicator$IND_CODE'].trim().substr(0, 8)
            } else if (map['pm_perf_case_indicator$LEVEL_NO'] === 2) {
              newMap['parentid'] = map['pm_perf_case_indicator$IND_CODE'].trim().substr(0, 4)
              newMap['parentGtId'] = map['pm_perf_case_indicator$IND_CODE'].trim().substr(0, 4)
            }
            newMap['children'] = null
            newData.push(newMap)
          })
          allData.target = newData
          allData.base = baseInfo
          this.$emit('data-insert', 'push', allData)
        } else {
        }
      }).catch(err => {
        console.log(err)
      })
    },
    // 下划线转驼峰
    toCamel(str) {
      return str.replace(/([^_])(?:_+([^_]))/g, function ($0, $1, $2) {
        return $1 + $2.toUpperCase()
      })
    },
    // 表头按钮点击事件
    handToBtn (tag) {
      if ((!this.currentRow || !('rowIndex' in this.currentRow)) && (tag !== 'reset' && tag !== 'push' && tag !== 'addTask' && tag !== 'deleteTask' && tag !== 'addt' && tag !== 'deletet')) {
        this.$message({
          message: '请先选择一条二级指标',
          type: 'warning'
        })
        return
      }
      this.formateCrtCellChild(this.currentRow)
      switch (tag) {
        case 'add':
          const item = { ...this.currentRow.subArr[this.currentRow.subArr.length - 1] }
          let newRow = {
            'zeroth': item.zeroth,
            'first': item.first,
            'second': item.second,
            'secondIndId': item.secondIndId ? item.secondIndId : item.parentid,
            'parentId': item.parentId ? item.parentId : item.parentid,
            'levelNo': item.levelNo,
            'id': this.$ToolFn.utilFn.getUuid(),
            'index': item.index,
            'rowIndex': item.rowIndex,
            'subArr': item.subArr
          }
          // let no = +item.no.slice(6)
          // no = (no + 1 + '').length === 3 ? (no + 1 + '')
          //   : (no + 1 + '').length === 2 ? `0${no + 1}`
          //     : `00${no + 1}`
          // item.no = item.no.slice(0, 6) + no
          this.form.splice(this.currentRow.rowIndex + this.currentRow.subArr.length, 0, newRow)
          this.renderTh() // 重新渲染表头，保证备注固定为textarea类型(最后一行的特殊类型)

          this.$emit('update:dataObj', this.form)
          break
        case 'insert':
          this.$emit('data-insert', 'insert')
          break
        case 'addTask':
          this.$emit('data-insert', 'addTask')
          break
        case 'deleteTask':
          this.$emit('data-insert', 'deleteTask')
          break
        case 'addt':
          this.$emit('data-insert', 'addt')
          break
        case 'deletet':
          this.$emit('data-insert', 'deletet')
          break
        case 'delete':
          if (this.currentRow.subArr.length <= 1 || this.deleteRow.rowIndex < this.currentRow.rowIndex ||
            this.deleteRow.rowIndex > this.currentRow.rowIndex + this.currentRow.subArr.length - 1) return
          if (this.currentCol.columnIndex >= 2) {
            this.form.splice(this.deleteRow.rowIndex, 1)
          } else { this.form.splice(this.currentRow.rowIndex + this.currentRow.subArr.length - 1, 1) }
          this.renderTh() // 重新渲染表头，保证备注固定为textarea类型(最后一行的特殊类型)

          this.tableConfig.mergeMethod.type === 'fieldMerge' &&
            this.getMergeArr(this.form, this.tableConfig.mergeMethod.value)

          this.$emit('update:dataObj', this.form)
          break
        case 'reset':
          // TODO
          this.$emit('data-insert', 'reset', { obj: '2' })
          break
        case 'push': // 案例推送
          // TODO get 安利推送下拉列表
          // this.pushList = pushData.targetappDeclare[0].base_dto.lists
          // qq
          // params
          if (this.$parent.formChangeData) {
            console.log(this.$parent.formChangeData)
            let apptype = this.$parent.crtTableType === 'deptjx' ? '60' : '11'
            let params = {
              appType: apptype,
              agencyCode: this.$parent.formChangeData.agency_code
              // proCatCode: this.$parent.formChangeData.pro_cat_code
            }
            getCase.getProCase(params).then(res => {
              if (res.code === 0) {
                if (res.content.records.length > 0) {
                  this.pushList = res.content.records
                  this.pushListcp = this.pushList
                } else {
                  this.$message.error('案例暂无数据哦!')
                  return false
                }
              } else {
                this.$message.error('查询案例失败!')
              }
            }).catch(err => {
              console.log(err)
            })
          } else {
            this.$message.error('请先选择项目类别!')
          }
          break
      }
    },
    // 获取服务端指标方向下拉配置
    getBudgtTypeOption() {
      let BUDGT_TYPE_OPTION = 'budgtTypeOption'
      let budgtTypeOptionList = Store(BUDGT_TYPE_OPTION)
      if (budgtTypeOptionList) {
        this.budgtTypeOption = budgtTypeOptionList
        return false
      }
      getCase.getDicTree({ 'dicCode': 'DIRECTION' }).then(res => {
        if (res.code === 0) {
          let newData = []
          let data = res.content
          data.forEach(map => {
            let newMap = {}
            newMap['value'] = Number(map.attributes.dicCode)
            newMap['label'] = map.attributes.dicName
            newData.push(newMap)
          })
          this.budgtTypeOption = newData
          Store(BUDGT_TYPE_OPTION, newData)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    // 获取服务端指标性质下拉配置
    getBudgtDirectionOption() {
      let BUDGT_DIRECTION_OPTION = 'budgtDirectionOption'
      let budgtDirectionOptionList = Store(BUDGT_DIRECTION_OPTION)
      if (budgtDirectionOptionList) {
        this.budgtDirectionOption = budgtDirectionOptionList
        return false
      }
      getCase.getDicTree({ 'dicCode': 'NATURE' }).then(res => {
        if (res.code === 0) {
          let newData = []
          let data = res.content
          data.forEach(map => {
            let newMap = {}
            newMap['value'] = Number(map.attributes.dicCode)
            newMap['label'] = map.attributes.dicName
            newData.push(newMap)
          })
          this.budgtDirectionOption = newData
          Store(BUDGT_DIRECTION_OPTION, newData)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    deepCopy(obj) {
      // 深拷贝通用方法
      let me = this
      if (typeof obj !== 'object' || obj === null) return obj
      let newObj = obj instanceof Array ? [] : {}
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          newObj[key] = typeof obj[key] === 'object' ? me.deepCopy(obj[key]) : obj[key]
        }
      }
      return newObj
    }
  },
  created() {
    this.getBudgtTypeOption()
    this.getBudgtDirectionOption()
  },
  mounted () {
  },
  watch: {
    dataObj: {
      immediate: true,
      deep: true,
      handler (val) {
        val && (this.form = val.map((k, index) => ({ ...k, index })))
        this.tableConfig.mergeMethod && this.tableConfig.mergeMethod.type === 'fieldMerge' &&
          this.getMergeArr(this.form, this.tableConfig.mergeMethod.value)
      }
    },
    tableConfig: {
      handler (val) {
        this.renderTh(val.thHead, val.thList)
      },
      immediate: true
    },
    type: {
      handler (val) {
      }
    }
  }
}
</script>
<style lang='scss'>
.el-table .hidden {
  display: none;
}
.el-table--border,
.el-table--group {
  border: 1px solid #ccc !important;
}
.el-table__body tr.current-row > td {
  background: #ffffff !important;
}
.el-table__body tr.current-row > td:hover {
  background: #ffffff !important;
}

.rgb196 {
  background: pink !important;
}

.rgb196 {
  background: pink !important;
}
.el-table td,
.el-table th {
  padding: 4px 0 !important;
}
.el-table {
  font-size: 13px !important;
}
.input-box input {
  border: none;
}
</style>
