const obj = {
  // 事前评估绩效目标申报表
  'sqpgjxmbsbb': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '事前评估绩效目标申报表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '第一列'
          },
          {
            prop: 'second',
            label: '第二列',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '第三列',
            childrenProp: {
              inputRows: [],
              disabledRows: [],
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '第四列',
            childrenProp: {
              inputRows: [],
              disabledRows: [],
              textAreaRows: []
            }
          },
          {
            prop: 'fifth',
            label: '第五列'
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [3, 0, 1, 2], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [3, 2, 1, 2],
          [1, 3, 1, 4],
          [1, 4, 1, 4],
          [0, 5, 4, 1],
          [2, 5, 1, 2],
          [1, 6, 1, 2],
          [1, 7, 1, 2],
          [1, 8, 1, 2]
        ]
      }
    },
    topDataMap: {
      // rowIndex_colIndex: {
      //   field: 'field',
      //   validator: {
      //     type: 'number||string',
      //     min: 10,
      //     max: 11,
      //     pattern: '',
      //     message: ''
      //   }
      // }
      '0__second': {
        field: 'pro_name'
      },
      '0__fourth': {
        field: 'dep_unitname'
      },
      '1__second': {
        field: 'distri_type_code'
      },
      '2__second': {
        field: 'pro_start_year'
      },
      '2__fourth': {
        field: 'pro_end_year'
      },
      '3__second': {
        field: 'pro_desc'
      },
      '4__second': {
        field: 'all_target'
      },
      '6__second': {
        field: 'cyc_cap'
      },
      '6__third': {
        field: 'budget_amt'
      }
    },
    bootomDataMap: {
      rowIndex_colIndex: {
      },
      'first': {
        field: 'field',
        validator: {
          type: 'number||string',
          min: 10,
          max: 11,
          pattern: '',
          message: ''
        }
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'first',
            label: '一级指标',
            width: 80,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            width: 80,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标',
            width: 80,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '内涵解释'
          },
          {
            prop: 'fifth',
            label: '设置依据'
          },
          {
            prop: 'sixth',
            label: '指标计算公式或方法'
          },
          {
            prop: 'seventh',
            label: '评分标准'
          },
          {
            prop: 'eighth',
            label: '关键指标(与预算安排直接挂钩的指标)'
          },
          {
            prop: 'ninth',
            label: '指标性质'
          },
          {
            prop: 'tenth',
            label: '指标方向'
          },
          {
            prop: 'eleventh',
            label: '2022年目标值'
          },
          {
            prop: 'twelfth',
            label: '计量单位'
          },
          {
            prop: 'thirteenth ',
            label: '指标新增方式'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '立项项目名称',
        second: '',
        third: '主管部门（单位）名称',
        fourth: '',
        fifth: '' // 单元格合并后，多余的字段宽度为0，故可借之来控制当前行高
      },
      {
        first: '分配方式'
      },
      {
        first: '项目开始时间',
        third: '项目结束时间'
      },
      {
        first: '项目概况'
      },
      {
        first: '总体目标'
      },
      {
        first: '专项资金情况（万元）',
        second: '资金来源 | 分类',
        third: '实施期',
        fourth: '当年度'
      },
      {
        first: '资金总额：'
      },
      {
        first: '财政拨款：'
      },
      {
        first: '其它资金：'
      }
    ]
  },
  'zxywjf': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '项目绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [9]
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 2, 3, 4, 7, 8], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              moneyRows: [5, 6]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [4],
              disabledRows: [4]
            }
          },
          {
            prop: 'fourth'
          },
          {
            prop: 'fifth'
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [1, 2, 1, 4],
          [1, 3, 1, 4],
          [0, 4, 4, 1],
          [0, 8, 3, 1],
          [2, 4, 1, 3],
          [1, 5, 1, 3],
          [1, 6, 1, 3],
          [1, 7, 1, 3],
          [1, 8, 1, 4],
          [0, 9, 1, 4]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值',
            width: 140
          },
          {
            prop: 'sixth',
            label: '计量单位',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'eighth',
            label: '分值'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目编码',
        second: '',
        third: ''
      },
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '实施单位',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: ''
      },
      {
        first: '财政拨款数',
        second: '',
        third: ''
      },
      {
        first: '非财政拨款数',
        third: '',
        second: ''
      },
      {
        first: '预算执行率权重（%）',
        third: '',
        second: ''
      },
      {
        first: '项目总体目标',
        third: '',
        second: '项目总体目标 (必填)'
      },
      {
        first: '',
        third: '',
        second: '' // 单元格合并后，多余的字段宽度为0，故可借之来控制当前行高
      }
    ]
  },
  'zxywjfys': { // 和zxywjf基本一样，改了文字几个说明
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '项目绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [9]
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 2, 3, 4, 7, 8], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              moneyRows: [5, 6]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [4],
              disabledRows: [4]
            }
          },
          {
            prop: 'fourth'
          },
          {
            prop: 'fifth'
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [1, 2, 1, 4],
          [1, 3, 1, 4],
          [0, 4, 4, 1],
          [0, 8, 3, 1],
          [2, 4, 1, 3],
          [1, 5, 1, 3],
          [1, 6, 1, 3],
          [1, 7, 1, 3],
          [1, 8, 1, 4],
          [0, 9, 1, 4]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值',
            width: 140
          },
          {
            prop: 'sixth',
            label: '计量单位',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'eighth',
            label: '分值'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目编码',
        second: '',
        third: ''
      },
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '实施单位',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '资金总额',
        third: ''
      },
      {
        first: '财政拨款数',
        second: '',
        third: ''
      },
      {
        first: '非财政拨款数',
        third: '',
        second: ''
      },
      {
        first: '预算执行率权重（%）',
        third: '',
        second: ''
      },
      {
        first: '年度目标',
        third: '',
        second: '年度目标 (必填)'
      },
      {
        first: '',
        third: '',
        second: '' // 单元格合并后，多余的字段宽度为0，故可借之来控制当前行高
      }
    ]
  },
  'zxzj': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项资金绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: false,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [6], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [6]
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 3, 4, 6], // 渲染为input框的行
              disabledRows: [0, 1, 3, 4], // 渲染为disabled的行
              textAreaRows: [6]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              inputRows: [2], // 渲染为input框的行
              disabledRows: [2] // 渲染为disabled的行
            }
          },
          {
            prop: 'fourth',
            childrenProp: {
              inputRows: [3, 4], // 渲染为input框的行
              disabledRows: [3, 4] // 渲染为disabled的行
            }
          },
          {
            prop: 'fifth',
            childrenProp: {
              inputRows: [2], // 渲染为input框的行
              disabledRows: [2] // 渲染为disabled的行
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [0, 2, 3, 1],
          [0, 5, 3, 1],
          [0, 6, 1, 2],
          [1, 5, 1, 2],
          [1, 6, 1, 2],
          [2, 5, 1, 2]

        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、项目名称指专项资金（政策）、部门预算专项业务费名称；   2、实施期指专项资金计划安排超过2年以上的要填写此项。  '
      },
      defaultInputCol: ['fourth', 'fifth', 'third'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称',
            childrenProp: {
              // inputRows: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '标准值'
          },
          {
            prop: 'fifth',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: '',
        fourth: '年度资金总额',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '其中：财政拨款',
        fourth: ''
      },
      {
        first: '其他',
        second: '',
        third: '其他资金',
        fourth: ''
      },
      {
        first: '总体目标',
        second: '总体目标',
        third: '年度目标'
      },
      {
        first: '',
        second: ''
      },
      {
        first: '',
        second: ''
      }
    ]
  },
  'zxzjtype': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项资金绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: false,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [6], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: []
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 6], // 渲染为input框的行
              disabledRows: [0, 1], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: [3, 4]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [2]
            }
          },
          {
            prop: 'fourth',
            label: '4',
            childrenProp: {
              moneyRows: [3, 4]
            }
          },
          {
            prop: 'fifth',
            label: '5',
            childrenProp: {
              moneyRows: [2]
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [0, 2, 3, 1],
          [0, 5, 3, 1],
          [0, 6, 1, 2],
          [1, 5, 1, 2],
          [1, 6, 1, 2],
          [2, 5, 1, 2]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      // noteProp: { // 备注配置
      //   isShowNote: false,
      //   noteField: 'third',
      //   disabled: true,
      //   noteValue: '备注：1、三级指标分值相加应等于90。  '
      // },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值'
          },
          {
            prop: 'sixth',
            label: '计量单位'
          },
          {
            prop: 'eighth',
            label: '分值'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: '',
        fourth: '年度资金总额',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '其中：财政拨款',
        fourth: ''
      },
      {
        first: '其他',
        second: '',
        third: '其他资金',
        fourth: ''
      },
      {
        first: '总体目标',
        second: '总体目标',
        third: '年度目标'
      },
      {
        first: '',
        second: ''
      },
      {
        first: '',
        second: ''
      }
    ]
  },
  'allzxzjtype': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项资金绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [6], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: []
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 6], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: [3, 4]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [2],
              disabledRows: [2, 3, 4]
            }
          },
          {
            prop: 'fourth',
            label: '4',
            childrenProp: {
              moneyRows: [3, 4],
              disabledRows: [0, 1, 3, 4] // 渲染为disabled的行
            }
          },
          {
            prop: 'fifth',
            label: '5',
            childrenProp: {
              moneyRows: [2],
              disabledRows: [2]
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [0, 2, 3, 1],
          [0, 5, 3, 1],
          [0, 6, 1, 2],
          [1, 5, 1, 2],
          [1, 6, 1, 2],
          [2, 5, 1, 2]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      // noteProp: { // 备注配置
      //   isShowNote: false,
      //   noteField: 'third',
      //   disabled: true,
      //   noteValue: '备注：1、三级指标分值相加应等于90。  '
      // },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          // {
          //   isTooltip: true,
          //   type: 'primary',
          //   text: '案例推送',
          //   size: 'mini',
          //   case: 'push'
          // },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值'
          },
          {
            prop: 'sixth',
            label: '计量单位'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
          // {
          //   prop: 'eighth',
          //   label: '分值'
          // }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: '',
        fourth: '年度资金总额',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '其中：财政拨款',
        fourth: ''
      },
      {
        first: '其他',
        second: '',
        third: '其他资金',
        fourth: ''
      },
      {
        first: '总体目标',
        second: '总体目标',
        third: '年度目标'
      },
      {
        first: '',
        second: ''
      },
      {
        first: '',
        second: ''
      }
    ]
  },
  'auditzxzjtype': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项资金绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [6], // 渲染为input框的行
              disabledRows: [6], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: []
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 6], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 6], // 渲染为disabled的行
              textAreaRows: [6],
              selectRows: [],
              moneyRows: [3, 4]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [2],
              disabledRows: [2, 3, 4]
            }
          },
          {
            prop: 'fourth',
            label: '4',
            childrenProp: {
              moneyRows: [3, 4],
              disabledRows: [0, 1, 3, 4] // 渲染为disabled的行
            }
          },
          {
            prop: 'fifth',
            label: '5',
            childrenProp: {
              moneyRows: [2],
              disabledRows: [2]
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [0, 2, 3, 1],
          [0, 5, 3, 1],
          [0, 6, 1, 2],
          [1, 5, 1, 2],
          [1, 6, 1, 2],
          [2, 5, 1, 2]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      // noteProp: { // 备注配置
      //   isShowNote: false,
      //   noteField: 'third',
      //   disabled: true,
      //   noteValue: '备注：1、三级指标分值相加应等于90。  '
      // },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fifth',
            label: '目标值',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'sixth',
            label: '计量单位',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'eighth',
            label: '分值',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'seventh',
            label: '备注',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              textAreaRows: []
            }
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: '',
        fourth: '年度资金总额',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '其中：财政拨款',
        fourth: ''
      },
      {
        first: '其他',
        second: '',
        third: '其他资金',
        fourth: ''
      },
      {
        first: '总体目标',
        second: '总体目标',
        third: '年度目标'
      },
      {
        first: '',
        second: ''
      },
      {
        first: '',
        second: ''
      }
    ]
  },
  'deptjx': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '年度绩效指标',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '1',
            width: 240,
            childrenProp: {
              inputRows: [3], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [3]
            }
          },
          {
            prop: 'second',
            label: '2',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 2], // 渲染为input框的行
              disabledRows: [0, 1, 2] // 渲染为disabled的行
            }
          },
          {
            prop: 'third',
            label: '3',
            childrenProp: {
              defaultRender: 'text',
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'fourth',
            label: '4'
          },
          {
            prop: 'fifth',
            label: '5'
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [0, 2, 3, 1],
          [1, 2, 1, 4],
          [0, 3, 1, 4]
        ]
      }
    },
    mid: {
      defaultInputCol: ['first', 'second', 'third'],
      style: 'border-bottom: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '新增任务',
            case: 'addTask'
          },
          {
            type: 'primary',
            size: 'mini',
            text: '删除任务',
            case: 'deleteTask'
          }
        ]
      },
      thList: {
        data: [
          {
            prop: 'first',
            label: '',
            width: 240,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '任务名称',
            width: 240
          },
          {
            prop: 'third',
            label: '主要内容'
          }
        ]
      },
      mergeMethod: {
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['first']
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、项目名称指专项资金（政策）、部门预算专项业务费名称；   2、实施期指专项资金计划安排超过2年以上的要填写此项。  '
      },
      defaultInputCol: ['third', 'fifth', 'sixth', 'seventh', 'eighth'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          // {
          //   isTooltip: true,
          //   type: 'primary',
          //   text: '案例推送',
          //   size: 'mini',
          //   case: 'push'
          // },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值'
          },
          {
            prop: 'sixth',
            label: '计量单位'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
          // {
          //   prop: 'eighth',
          //   label: '分值'
          // }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '部门名称及编码',
        second: '',
        third: ''
      },
      {
        first: '业务处室名称',
        second: '',
        third: ''
      },
      {
        first: '年度目标',
        third: '',
        second: '年度目标 (必填)'
      },
      {
        first: '',
        third: '',
        second: '' // 单元格合并后，多余的字段宽度为0，故可借之来控制当前行高
      }
    ]
  },
  'outbmjx': { // 部门整体
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '项目绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            width: 80,
            childrenProp: {
              inputRows: [6, 7, 8, 9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            width: 80,
            childrenProp: {
              inputRows: [0, 2, 3, 4, 6, 7, 8, 9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [4]
            }
          },
          {
            prop: 'third',
            width: 200,
            childrenProp: {
              inputRows: [1, 6, 7, 8, 9], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'forth',
            width: 400,
            childrenProp: {
              inputRows: [0, 6, 7, 8, 9], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'fifth',
            width: 300,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'sixth',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [ // 列数，行数 rowSpan， colspan
          [0, 0, 1, 2],
          [0, 1, 3, 1],
          [1, 1, 1, 2],
          [0, 2, 1, 2],
          [0, 3, 1, 2],
          [1, 0, 1, 2],
          [3, 0, 1, 2],
          [2, 1, 1, 4],
          [1, 2, 1, 4],
          [1, 3, 1, 4],
          [1, 4, 1, 5],
          [0, 5, 5, 1],
          [1, 5, 1, 2],
          [0, 6, 1, 2],
          [0, 7, 1, 2],
          [0, 8, 1, 2],
          [0, 9, 1, 2]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '内涵解释',
            width: 140
          },
          {
            prop: 'targetCharacter',
            label: '设置依据',
            width: 140
          },
          {
            prop: 'fifth',
            label: '指标计算公式或方法',
            width: 140
          },
          {
            prop: 'sixth',
            label: '评分标准',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'seventh',
            label: '目标值'
          },
          {
            prop: 'eighth',
            label: '指标审核'
          },
          {
            prop: 'tenth',
            label: '业务处审核意见'
          },
          {
            prop: 'eleventh',
            label: '绩效处审核意见'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '部门(单位)名称',
        second: '',
        third: '部门预算编码',
        forth: ''
      },
      {
        first: '年度预算安排（万元）',
        second: '资金总额',
        third: ''
      },
      {
        first: '项目支出',
        second: '',
        third: ''
      },
      {
        first: '基本支出',
        second: ''
      },
      {
        first: '年度总体目标',
        second: ''
      },
      {
        first: '年度履职目标',
        second: '部门职能',
        third: '年度目标任务',
        forth: '支出项目任务',
        fifth: '预算金额（万元）'
      },
      {
        first: '',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      }
    ]
  },
  'budgetmbsb': { // 专项资金绩效
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项资金绩效目标申报表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            width: 120,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            childrenProp: {
              inputRows: [0, 1, 2, 3, 4, 5, 6, 8, 10, 11, 12, 13], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [6, 12, 13]
            }
          },
          {
            prop: 'third',
            childrenProp: {
              inputRows: [7, 9], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'forth',
            childrenProp: {
              inputRows: [0, 1, 4, 5], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'fifth',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'sixth',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'seventh',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [// 列数，行数 rowSpan， colspan
          [1, 0, 1, 3],
          [3, 0, 1, 2],
          [1, 1, 1, 3],
          [3, 1, 1, 2],
          [1, 4, 1, 3],
          [3, 4, 1, 2],
          [1, 5, 1, 3],
          [3, 5, 1, 2],
          [0, 7, 2, 1],
          [0, 9, 3, 1],
          [1, 2, 1, 6],
          [1, 3, 1, 6],
          [1, 6, 1, 6],
          [2, 7, 1, 5],
          [1, 8, 1, 5],
          [2, 9, 1, 5],
          [1, 10, 1, 5],
          [1, 11, 1, 5],
          [1, 12, 1, 6],
          [1, 13, 1, 6]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: ''
          },
          {
            prop: 'first',
            label: '一级指标'
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称'
          },
          {
            prop: 'fourth',
            label: '内涵解释'
          },
          {
            prop: 'targetCharacter',
            label: '设置依据'
          },
          {
            prop: 'fifth',
            label: '指标计算公式或方法'
          },
          {
            prop: 'sixth',
            label: '评分标准',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'seventh',
            label: '关键指标(与预算安排直接挂钩的指标)'
          },
          {
            prop: 'eighth',
            label: '半年目标'
          },
          {
            prop: 'tenth',
            label: '目标值'
          },
          {
            prop: 'eleventh',
            label: '指标审核'
          },
          {
            prop: 'twelfth',
            label: '业务处审核意见'
          },
          {
            prop: 'thirteenth',
            label: '绩效处审核意见'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目编码',
        second: '',
        third: '项目名称',
        fifth: ''
      },
      {
        first: '单位编码',
        second: '',
        third: '单位名称',
        fifth: ''
      },
      {
        first: '项目类别',
        second: ''
      },
      {
        first: '存续状态',
        second: ''
      },
      {
        first: '项目负责人',
        second: '',
        third: '联系电话',
        forth: '',
        fifth: ''
      },
      {
        first: '项目开始时间',
        second: '',
        third: '项目结束时间',
        forth: '',
        fifth: ''
      },
      {
        first: '项目概况',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '项目立项情况',
        second: '项目立项依据',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '项目申报的可行性',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '专项资金情况（万元）',
        second: '资金总额：',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '其他资金',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '项目实施期目标',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '备注',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      }
    ]
  },
  'depmbsb': { // 部门业务费绩效
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '部门业务费绩效目标申报表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            width: 120,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            childrenProp: {
              inputRows: [1, 2, 3, 4], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [3, 4]
            }
          },
          {
            prop: 'third',
            childrenProp: {
              inputRows: [0], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'forth',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          },
          {
            prop: 'fifth',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              moneyRows: [],
              textAreaRows: [],
              disabledRows: []
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [// 列数，行数 rowSpan， colspan
          [0, 0, 3, 1],
          [1, 1, 1, 3],
          [1, 2, 1, 3],
          [1, 3, 1, 4],
          [1, 4, 1, 4],
          [2, 0, 1, 3]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: ''
          },
          {
            prop: 'first',
            label: '一级指标'
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称'
          },
          {
            prop: 'fourth',
            label: '内涵解释'
          },
          {
            prop: 'targetCharacter',
            label: '设置依据'
          },
          {
            prop: 'fifth',
            label: '指标计算公式或方法'
          },
          {
            prop: 'sixth',
            label: '评分标准',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'seventh',
            label: '半年目标'
          },
          {
            prop: 'eighth',
            label: '目标值'
          },
          {
            prop: 'tenth',
            label: '指标审核'
          },
          {
            prop: 'eleventh',
            label: '业务处审核意见'
          },
          {
            prop: 'twelfth',
            label: '绩效处审核意见'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '专项资金情况(万元)',
        second: '实施期资金总额：',
        third: '',
        fifth: ''
      },
      {
        first: '其中：财政拨款',
        second: '',
        third: '',
        fifth: ''
      },
      {
        first: '其他资金',
        second: ''
      },
      {
        first: '年度目标',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      },
      {
        first: '备注',
        second: '',
        third: '',
        forth: '',
        fifth: ''
      }
    ]
  },
  // 默认底部table数据
  publicDefaultBottomData: {
    'id': '0',
    'indName': '绩效指标',
    'children': [
      {
        'proId': null,
        'agencyCode': null,
        'agencyName': null,
        'proCode': null,
        'proName': null,
        'indId': '7555fe798ce694aa8b71baa9bb54ba35',
        'indCode': '0001',
        'indName': '产出指标',
        'targetWeight': null,
        'levelNo': 1,
        'targetCharacter': null,
        'targetDirection': null,
        'targetDescription': null,
        'targetRemark': null,
        'standardDesc': null,
        'centerTarget': null,
        'targetType': null,
        'standardValue': null,
        'tyfValue': null,
        'lytValue': null,
        'lyfValue': null,
        'hytValue': null,
        'cytValue': null,
        'finaIsDeleted': null,
        'pemsIsDeleted': null,
        'finaAuditOpinion': null,
        'pemsAuditOpinion': null,
        'finaExpectValue': null,
        'expectValue': null,
        'calculation': null,
        'attachNo': null,
        'creater': null,
        'createTime': '2020-09-24 09:17:00',
        'firstTargetId': null,
        'firstTargetName': null,
        'secondTargetId': null,
        'secondTargetName': null,
        'gtId': '7555fe798ce694aa8b71baa9bb54ba35',
        'parentGtId': '0',
        'filesCount': null,
        'kpiPerId': null,
        'gotaReserve1': null,
        'gotaReserve2': null,
        'gotaReserve3': null,
        'gotaReserve4': null,
        'gotaReserve5': null,
        'gotaReserve6': null,
        'gotaReserve7': null,
        'gotaReserve8': null,
        'gotaReserve9': null,
        'gotaReserve10': null,
        'children': [
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba50',
            'indCode': '00010001',
            'indName': '数量指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba50',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba35',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': '6ADCDC8CFFE3B2437849EE2723A2B9F644DB',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba50',
                'modelTableName': null,
                'bigData': null,
                'tempId': '6ADCDC8CFFE3B2437849EE2723A2B9F644DB',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba35',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba50'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba50',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba35',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba39',
            'indCode': '00010002',
            'indName': '质量指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba39',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba35',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': 'DFA6E08DC275F44D9FFA8F87D3C9823FEE79',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba39',
                'modelTableName': null,
                'bigData': null,
                'tempId': 'DFA6E08DC275F44D9FFA8F87D3C9823FEE79',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba35',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba39'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba39',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba35',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba40',
            'indCode': '00010003',
            'indName': '时效指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba40',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba35',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': '1010BB095BEE4D4A75A9DC9812EF11FA64C0',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba40',
                'modelTableName': null,
                'bigData': null,
                'tempId': '1010BB095BEE4D4A75A9DC9812EF11FA64C0',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba35',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba40'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba40',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba35',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba38',
            'indCode': '00010004',
            'indName': '成本指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba38',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba35',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': 'AAC296BF703F294AB1BBD49A56CCB1A3F2EB',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
                'modelTableName': null,
                'bigData': null,
                'tempId': 'AAC296BF703F294AB1BBD49A56CCB1A3F2EB',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba35',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba38'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba38',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba35',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          }
        ],
        'goalId': null,
        'id': '7555fe798ce694aa8b71baa9bb54ba35',
        'parentId': '0',
        'modelTableName': 'PM_PERF_INDICATOR',
        'bigData': false
      },
      {
        'proId': null,
        'agencyCode': null,
        'agencyName': null,
        'proCode': null,
        'proName': null,
        'indId': '7555fe798ce694aa8b71baa9bb54ba36',
        'indCode': '0002',
        'indName': '效益指标',
        'targetWeight': null,
        'levelNo': 1,
        'targetCharacter': null,
        'targetDirection': null,
        'targetDescription': null,
        'targetRemark': null,
        'standardDesc': null,
        'centerTarget': null,
        'targetType': null,
        'standardValue': null,
        'tyfValue': null,
        'lytValue': null,
        'lyfValue': null,
        'hytValue': null,
        'cytValue': null,
        'finaIsDeleted': null,
        'pemsIsDeleted': null,
        'finaAuditOpinion': null,
        'pemsAuditOpinion': null,
        'finaExpectValue': null,
        'expectValue': null,
        'calculation': null,
        'attachNo': null,
        'creater': null,
        'createTime': '2020-09-24 09:17:00',
        'firstTargetId': null,
        'firstTargetName': null,
        'secondTargetId': null,
        'secondTargetName': null,
        'gtId': '7555fe798ce694aa8b71baa9bb54ba36',
        'parentGtId': '0',
        'filesCount': null,
        'kpiPerId': null,
        'gotaReserve1': null,
        'gotaReserve2': null,
        'gotaReserve3': null,
        'gotaReserve4': null,
        'gotaReserve5': null,
        'gotaReserve6': null,
        'gotaReserve7': null,
        'gotaReserve8': null,
        'gotaReserve9': null,
        'gotaReserve10': null,
        'children': [
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba42',
            'indCode': '00020001',
            'indName': '经济效益指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba42',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba36',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': '21771D1BF57ED849DA3A120AD3326F947A5B',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba42',
                'modelTableName': null,
                'bigData': null,
                'tempId': '21771D1BF57ED849DA3A120AD3326F947A5B',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba36',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba42'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba42',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba36',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba43',
            'indCode': '00020002',
            'indName': '社会效益指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba43',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba36',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': 'A83EC743B393F84402C91A734A1183B92EF5',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba43',
                'modelTableName': null,
                'bigData': null,
                'tempId': 'A83EC743B393F84402C91A734A1183B92EF5',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba36',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba43'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba43',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba36',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba44',
            'indCode': '00020003',
            'indName': '生态效益指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba44',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba36',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': '943D73F8C0521441C1F820F2C310650BAED0',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba44',
                'modelTableName': null,
                'bigData': null,
                'tempId': '943D73F8C0521441C1F820F2C310650BAED0',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba36',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba44'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba44',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba36',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          },
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba45',
            'indCode': '00020004',
            'indName': '可持续影响指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba45',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba36',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': '1CED12B49FC3F14985A8945C4659F8AE0A9D',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba45',
                'modelTableName': null,
                'bigData': null,
                'tempId': '1CED12B49FC3F14985A8945C4659F8AE0A9D',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba36',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba45'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba45',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba36',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          }
        ],
        'goalId': null,
        'id': '7555fe798ce694aa8b71baa9bb54ba36',
        'parentId': '0',
        'modelTableName': 'PM_PERF_INDICATOR',
        'bigData': false
      },
      {
        'proId': null,
        'agencyCode': null,
        'agencyName': null,
        'proCode': null,
        'proName': null,
        'indId': '7555fe798ce694aa8b71baa9bb54ba37',
        'indCode': '0003',
        'indName': '满意度指标',
        'targetWeight': null,
        'levelNo': 1,
        'targetCharacter': null,
        'targetDirection': null,
        'targetDescription': null,
        'targetRemark': null,
        'standardDesc': null,
        'centerTarget': null,
        'targetType': null,
        'standardValue': null,
        'tyfValue': null,
        'lytValue': null,
        'lyfValue': null,
        'hytValue': null,
        'cytValue': null,
        'finaIsDeleted': null,
        'pemsIsDeleted': null,
        'finaAuditOpinion': null,
        'pemsAuditOpinion': null,
        'finaExpectValue': null,
        'expectValue': null,
        'calculation': null,
        'attachNo': null,
        'creater': null,
        'createTime': '2020-09-24 09:17:00',
        'firstTargetId': null,
        'firstTargetName': null,
        'secondTargetId': null,
        'secondTargetName': null,
        'gtId': '7555fe798ce694aa8b71baa9bb54ba37',
        'parentGtId': '0',
        'filesCount': null,
        'kpiPerId': null,
        'gotaReserve1': null,
        'gotaReserve2': null,
        'gotaReserve3': null,
        'gotaReserve4': null,
        'gotaReserve5': null,
        'gotaReserve6': null,
        'gotaReserve7': null,
        'gotaReserve8': null,
        'gotaReserve9': null,
        'gotaReserve10': null,
        'children': [
          {
            'proId': null,
            'agencyCode': null,
            'agencyName': null,
            'proCode': null,
            'proName': null,
            'indId': '7555fe798ce694aa8b71baa9bb54ba46',
            'indCode': '00030001',
            'indName': '服务对象满意度指标',
            'targetWeight': null,
            'levelNo': 2,
            'targetCharacter': null,
            'targetDirection': null,
            'targetDescription': null,
            'targetRemark': null,
            'standardDesc': null,
            'centerTarget': null,
            'targetType': null,
            'standardValue': null,
            'tyfValue': null,
            'lytValue': null,
            'lyfValue': null,
            'hytValue': null,
            'cytValue': null,
            'finaIsDeleted': null,
            'pemsIsDeleted': null,
            'finaAuditOpinion': null,
            'pemsAuditOpinion': null,
            'finaExpectValue': null,
            'expectValue': null,
            'calculation': null,
            'attachNo': null,
            'creater': null,
            'createTime': '2020-09-24 09:17:00',
            'firstTargetId': null,
            'firstTargetName': null,
            'secondTargetId': null,
            'secondTargetName': null,
            'gtId': '7555fe798ce694aa8b71baa9bb54ba46',
            'parentGtId': '7555fe798ce694aa8b71baa9bb54ba37',
            'filesCount': null,
            'kpiPerId': null,
            'gotaReserve1': null,
            'gotaReserve2': null,
            'gotaReserve3': null,
            'gotaReserve4': null,
            'gotaReserve5': null,
            'gotaReserve6': null,
            'gotaReserve7': null,
            'gotaReserve8': null,
            'gotaReserve9': null,
            'gotaReserve10': null,
            'children': [
              {
                'proId': null,
                'agencyCode': null,
                'agencyName': null,
                'proCode': null,
                'proName': null,
                'indId': null,
                'indCode': null,
                'indName': null,
                'targetWeight': null,
                'levelNo': null,
                'targetCharacter': null,
                'targetDirection': null,
                'targetDescription': null,
                'targetRemark': null,
                'standardDesc': null,
                'centerTarget': null,
                'targetType': null,
                'standardValue': null,
                'tyfValue': null,
                'lytValue': null,
                'lyfValue': null,
                'hytValue': null,
                'cytValue': null,
                'finaIsDeleted': null,
                'pemsIsDeleted': null,
                'finaAuditOpinion': null,
                'pemsAuditOpinion': null,
                'finaExpectValue': null,
                'expectValue': null,
                'calculation': null,
                'attachNo': null,
                'creater': null,
                'createTime': null,
                'firstTargetId': null,
                'firstTargetName': null,
                'secondTargetId': null,
                'secondTargetName': null,
                'gtId': null,
                'parentGtId': null,
                'filesCount': null,
                'kpiPerId': null,
                'gotaReserve1': null,
                'gotaReserve2': null,
                'gotaReserve3': null,
                'gotaReserve4': null,
                'gotaReserve5': null,
                'gotaReserve6': null,
                'gotaReserve7': null,
                'gotaReserve8': null,
                'gotaReserve9': null,
                'gotaReserve10': null,
                'children': null,
                'goalId': null,
                'id': 'E89A819C287F104D1CA9ECB418D51757C94C',
                'parentId': '7555fe798ce694aa8b71baa9bb54ba46',
                'modelTableName': null,
                'bigData': null,
                'tempId': 'E89A819C287F104D1CA9ECB418D51757C94C',
                'parent_parent_id': '7555fe798ce694aa8b71baa9bb54ba37',
                'parent_target_id': '7555fe798ce694aa8b71baa9bb54ba46'
              }
            ],
            'goalId': null,
            'id': '7555fe798ce694aa8b71baa9bb54ba46',
            'parentId': '7555fe798ce694aa8b71baa9bb54ba37',
            'modelTableName': 'PM_PERF_INDICATOR',
            'bigData': false
          }
        ],
        'goalId': null,
        'id': '7555fe798ce694aa8b71baa9bb54ba37',
        'parentId': '0',
        'modelTableName': 'PM_PERF_INDICATOR',
        'bigData': false
      }
    ]
  },
  'bmzt': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项业务经费绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            width: 130,
            prop: 'first',
            align: 'center',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            align: 'center',
            label: '金额',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'third',
            align: 'center',
            style: 'text-align: center',
            width: 500,
            childrenProp: {
              defaultRender: 'text',
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'fourth',
            align: 'center',
            childrenProp: {
              defaultRender: 'text',
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'fifth',
            label: '金额',
            childrenProp: {
              defaultRender: 'text',
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'sixth',
            label: '金额',
            childrenProp: {
              defaultRender: 'text',
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 5], // 列数，行数， rowSpan， colspan
          [0, 1, 7, 1],
          [1, 1, 2, 1],
          [2, 1, 2, 1],
          [3, 1, 1, 3],
          [0, 7, 1, 2],
          [1, 8, 1, 5]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、项目名称指专项资金（政策）、部门预算专项业务费名称；   2、实施期指专项资金计划安排超过2年以上的要填写此项。  '
      },
      defaultInputCol: ['fourth', 'fifth', 'third'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称',
            required: 'true',
            childrenProp: {
              // inputRows: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '标准值'
          },
          {
            prop: 'fifth',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '部门（单位）名称',
        second: '133333333'
      },
      {
        first: '部门（单位）名称',
        second: '任务名称',
        third: '主要内容',
        fourth: '预算金额'
      },
      {
        first: '总额',
        second: '财政拨款',
        third: '其他资金'
      },
      {
        first: '任务1',
        second: '133333333',
        third: '',
        fourth: '22',
        fifth: '222'
      },
      {
        first: '任务2',
        second: '133333333',
        third: '',
        fourth: '22',
        fifth: '222'
      },
      {
        first: '任务3',
        second: '133333333',
        third: '',
        fourth: '22',
        fifth: '222'
      },
      {
        first: '任务4',
        second: '133333333',
        third: '',
        fourth: '22',
        fifth: '222'
      },
      {
        first: '金额合计',
        second: '133333333',
        third: '',
        fourth: '22'
      },
      {
        first: '年度总体目标',
        second: '133333333',
        third: '223'
      }
    ]
  },
  'rygz': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '专项业务经费绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'third',
            label: '金额类别',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [] // 渲染为disabled的行
            }
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 2], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 2],
          [1, 2, 1, 2],
          [1, 3, 1, 2],
          [1, 4, 1, 2],
          [1, 5, 1, 2]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、项目名称指专项资金（政策）、部门预算专项业务费名称；   2、实施期指专项资金计划安排超过2年以上的要填写此项。  '
      },
      defaultInputCol: ['fourth', 'fifth', 'third'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标'
          },
          {
            prop: 'third',
            label: '三级指标名称',
            childrenProp: {
              // inputRows: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '标准值'
          },
          {
            prop: 'fifth',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目名称',
        second: '133333333'
      },
      {
        first: '主管部门',
        second: '2'
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额'
      },
      {
        first: '其他',
        second: '4'
      },
      {
        first: '资金金额(万元)',
        second: '4',
        third: '22'
      },
      {
        first: '总体目标',
        second: '4',
        third: '22'
      }
    ]
  },
  // 专项资金-项目绩效
  'zxzjxmjx': {
    top: {
      style: 'border-bottom: none !important',
      thHead: {
        type: 'text', // text || btns
        values: [
          {
            el: 'div',
            text: '项目绩效目标表',
            style: 'text-align: center'
          },
          {
            el: 'div',
            style: 'text-align: center'
          }
        ]
      },
      thList: {
        hidden: true,
        data: [
          {
            prop: 'first',
            label: '部门名称',
            width: 240,
            childrenProp: {
              inputRows: [9], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: [9]
            }
          },
          {
            prop: 'second',
            label: '金额类别',
            width: 240,
            childrenProp: {
              inputRows: [0, 1, 2, 3, 4, 7, 8], // 渲染为input框的行
              disabledRows: [0, 1, 2, 3, 4, 5, 6, 7, 8], // 渲染为disabled的行
              moneyRows: [5, 6]
            }
          },
          {
            prop: 'third',
            label: '金额',
            childrenProp: {
              moneyRows: [4],
              disabledRows: [4]
            }
          },
          {
            prop: 'fourth'
          },
          {
            prop: 'fifth'
          }
        ]
      },
      mergeMethod: {
        type: 'indexMerge', // fieldMerge || indexMerge
        value: [
          [1, 0, 1, 4], // 列数，行数 rowSpan， colspan
          [1, 1, 1, 4],
          [1, 2, 1, 4],
          [1, 3, 1, 4],
          [0, 4, 4, 1],
          [0, 8, 3, 1],
          [2, 4, 1, 3],
          [1, 5, 1, 3],
          [1, 6, 1, 3],
          [1, 7, 1, 3],
          [1, 8, 1, 4],
          [0, 9, 1, 4]
        ]
      }
    },
    bottom: {
      activeCol: 'second',
      noteProp: { // 备注配置
        isShowNote: false,
        noteField: 'third',
        disabled: true
        // noteValue: '备注：1、三级指标分值相加应等于90。  '
      },
      defaultInputCol: ['fifth', 'sixth', 'seventh', 'eighth', 'third'],
      defaultSelectCol: ['targetCharacter', 'fourth'],
      style: 'border-top: none !important',
      thHead: { // 表头配置
        style: 'text-align: right',
        type: 'btns', // text 文本 || btns 按钮集合
        values: [
          {
            type: 'primary',
            size: 'mini',
            text: '指标库挑选',
            case: 'insert'
          },
          {
            isTooltip: true,
            type: 'primary',
            text: '案例推送',
            size: 'mini',
            case: 'push'
          },
          {
            type: 'primary',
            text: '新增',
            size: 'mini',
            case: 'add'
          },
          {
            type: 'primary',
            text: '删除',
            size: 'mini',
            case: 'delete'
          },
          {
            type: 'primary',
            text: '重置',
            size: 'mini',
            case: 'reset'
          }
        ]
      },
      thList: {
        hidden: false, //  是否隐藏表头
        data: [
          {
            prop: 'zeroth',
            label: '',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textRows: []
            }
          },
          {
            prop: 'first',
            label: '一级指标',
            width: 100,
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'second',
            label: '二级指标',
            childrenProp: {
              inputRows: [], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'third',
            label: '三级指标名称',
            width: 300,
            childrenProp: {
              inputRows: [0, 1, 2, 3, 4], // 渲染为input框的行
              disabledRows: [], // 渲染为disabled的行
              textAreaRows: []
            }
          },
          {
            prop: 'fourth',
            label: '指标方向',
            width: 140
          },
          {
            prop: 'targetCharacter',
            label: '指标性质',
            width: 140
          },
          {
            prop: 'fifth',
            label: '目标值',
            width: 140
          },
          {
            prop: 'sixth',
            label: '计量单位',
            childrenProp: {
              disabledRows: [] // 渲染为disabled的行
            }
          },
          {
            prop: 'eighth',
            label: '分值'
          },
          {
            prop: 'seventh',
            label: '备注'
          }
        ]
      },
      mergeMethod: { //  行列合并方法： fieldMerge根据字段纵向合并，indexMerge根据给定value强制合并
        type: 'fieldMerge', // fieldMerge || indexMerge
        value: ['zeroth', 'first', 'second']
      }
    },
    defaultTopData: [
      {
        first: '项目编码',
        second: '',
        third: ''
      },
      {
        first: '项目名称',
        second: '',
        third: ''
      },
      {
        first: '主管部门',
        second: ''
      },
      {
        first: '实施单位',
        second: ''
      },
      {
        first: '资金金额(万元)',
        second: '实施期资金总额',
        third: ''
      },
      {
        first: '财政拨款数',
        second: '',
        third: ''
      },
      {
        first: '非财政拨款数',
        third: '',
        second: ''
      },
      {
        first: '预算执行率权重（%）',
        third: '',
        second: ''
      },
      {
        first: '项目总体目标',
        third: '',
        second: '项目总体目标 (必填)'
      },
      {
        first: '',
        third: '',
        second: '' // 单元格合并后，多余的字段宽度为0，故可借之来控制当前行高
      }
    ]
  },
  'threeData': {
    'code': 0,
    'success': true,
    'content': {
      'records': [
        {
          'indId': '02bc27bfb611702dc411bd13732d131f',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417902',
          'indName': '<em style=\'color:red\'>造林</em>面积增长率（%）',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察开展造林工作的单位成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '造林单位成本=实际造林总成本/总造林面积',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '1',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-071',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-237',
          'zjytText': '森林资源培育',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '48c80f45474993680cee0d5c795eba8f',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417912',
          'indName': '建设单位成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察开展项目建设的单位成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '建设单位成本=实际建设总成本/总建设面积',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-072',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-242',
          'zjytText': '水利工程建设及运行管理',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '9be48cd08589ed499db1ad0cfc26877c',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417916',
          'indName': '单病种均次费用',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，否则按实际值/计划值*指标分值计分',
          'targetDescription': '考察单病种平均每次所需诊疗费用情况',
          'targetCharacter': 1,
          'targetDirection': 3,
          'targetDirections': 3,
          'calculation': '元/次',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '单病种均次费用=单病种总费用/就诊次数',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '210',
          'targetAttribute': '1',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-005',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:17:57',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:17:57',
          'operator': null,
          'zjyt': 'ZJYT-255',
          'zjytText': '其他公立医院支出',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_007',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '4e2fb349c80d4477fb9053fe9bc01a71',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417932',
          'indName': '223123',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': null,
          'targetDescription': '22',
          'targetCharacter': null,
          'targetDirection': 2,
          'targetDirections': null,
          'calculation': '22',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': null,
          'targetSource': '222',
          'mofDivCode': '100000000',
          'unitno': '119102003',
          'budYear': null,
          'funcCode': null,
          'targetAttribute': null,
          'tradeStandardValue': 'HY_002',
          'localStandardValue': null,
          'targetCatagory': 'LY-007',
          'targetVersion': null,
          'targetScope': '仅本部门使用',
          'openDate': '2021-07-02 22:12:30',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-07-02 22:12:30',
          'operator': '722846E63E73404BAE73C8D318FAF1A9',
          'zjyt': 'ZJYT-206',
          'zjytText': '教学设施建设维护',
          'scope': null,
          'usedType': '1',
          'businessType': null,
          'targetClassify': null,
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': '7555fe798ce694aa8b71baa9bb54ba35',
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '6a63c5c2ebfd429de1f3fc34464c50be',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417909',
          'indName': '维修维护单位成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察维修维护成本是否有效控制',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '维修单位成本=实际维修总成本/总维修数量',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-071',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-240',
          'zjytText': '湿地、自然保护区、林场、国家公园等保护与管理',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '87514687fb19cb1e8b86b5781e6e6165',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417898',
          'indName': '出差人均成本',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察项目出差的单位成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元/人',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '出差人均成本=实际出差总成本/总人次',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '1',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-070',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:58',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:58',
          'operator': null,
          'zjyt': 'ZJYT-224',
          'zjytText': '农产品质量安全和执法监管',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '95e58be700d55d556c5a5e660babceca',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417924',
          'indName': '预算（成本）控制率',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，若高出标准则每高出5%扣10分，扣完为止',
          'targetDescription': '考察项目预算成本是否控制在标准范围内',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '%',
          'standardValue': null,
          'planValue': '0',
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '预算（成本）控制率=（项目当期实际支出成本-项目当期预算）/项目当期预算*100%',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': null,
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-076',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:22:51',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:22:51',
          'operator': null,
          'zjyt': 'ZJYT-268',
          'zjytText': '信息化运行维护类',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_035',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': 'c18355c37bb9a80496a3a28041e1234f',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417913',
          'indName': '购置单位成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察购置成本是否有效控制',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '购置单位成本=实际购置总成本/总购置数量',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-046',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-238',
          'zjytText': '社会发展',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': 'c5ac19e4ded9d8c83627e7989467b7cc',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417895',
          'indName': '国家试点营养膳食生均补助标准',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，否则按实际值/计划值*指标分值计分',
          'targetDescription': '考察国家试点地区营养膳食基本补助标准',
          'targetCharacter': 1,
          'targetDirection': 2,
          'targetDirections': 2,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '数据统计',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '205',
          'targetAttribute': '1',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-064',
          'targetVersion': null,
          'targetScope': null,
          'openDate': '2021-03-10 08:06:11',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 08:06:11',
          'operator': null,
          'zjyt': 'ZJYT-0177',
          'zjytText': '支持城乡义务教育发展',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_003',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': 'd190c43d23c550c94e25f1807122714a',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417903',
          'indName': '购置单位成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察购置成本是否有效控制',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '购置单位成本=实际购置总成本/总购置数量',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-071',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-217',
          'zjytText': '动植物保护',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '08b194b8c3e972da641050744895d1f7',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417907',
          'indName': '新植树平均成本',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察新植树平均成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '新植树平均成本=新植树总成本/新植树总数量',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '213',
          'targetAttribute': '1',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-071',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:14:59',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:14:59',
          'operator': null,
          'zjyt': 'ZJYT-240',
          'zjytText': '湿地、自然保护区、林场、国家公园等保护与管理',
          'scope': '2',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_010',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': 'de8554595c7505c2c27eb384e25fe0b7',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417931',
          'indName': '这是一个指标',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': null,
          'targetDescription': '33',
          'targetCharacter': null,
          'targetDirection': 2,
          'targetDirections': null,
          'calculation': '33',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': null,
          'targetSource': '333',
          'mofDivCode': '100000000',
          'unitno': '21',
          'budYear': null,
          'funcCode': null,
          'targetAttribute': null,
          'tradeStandardValue': 'HY_003',
          'localStandardValue': null,
          'targetCatagory': 'LY-007',
          'targetVersion': null,
          'targetScope': '不定向使用',
          'openDate': '2021-07-02 21:05:03',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-07-02 21:05:03',
          'operator': '1000_admin',
          'zjyt': 'ZJYT-215',
          'zjytText': '学生综合素质提升',
          'scope': null,
          'usedType': '1',
          'businessType': null,
          'targetClassify': null,
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': '7555fe798ce694aa8b71baa9bb54ba35',
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '60555d196d3b4eb0b683915bb03ae574',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417922',
          'indName': '线路租用成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察线路租用的成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '数据统计',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': null,
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-076',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:22:51',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:22:51',
          'operator': null,
          'zjyt': 'ZJYT-267',
          'zjytText': '信息化新建改造类',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_035',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '7eb47a8db8849561ab3ceec7f683d31d',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417892',
          'indName': '人均培训成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察人均培训的成本是否达到标准',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '人均培训成本=培训支出/参训人数',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '205',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-063',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 08:06:11',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 08:06:11',
          'operator': null,
          'zjyt': 'ZJYT-200',
          'zjytText': '教师进修',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_003',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '80440b21df75c574a65bd6d818b4c39a',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417923',
          'indName': '数据采购成本',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '不超过计划值得满分，否则不得分',
          'targetDescription': '考察数据采购的成本情况',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '数据统计',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': null,
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-076',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:22:51',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:22:51',
          'operator': null,
          'zjyt': 'ZJYT-267',
          'zjytText': '信息化新建改造类',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_035',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '89b577781f56ff31629d1724849af10a',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417897',
          'indName': '预算（成本）控制率',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，若高出标准则每高出5%扣10分，扣完为止',
          'targetDescription': '考察项目预算成本是否控制在标准范围内',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '%',
          'standardValue': null,
          'planValue': '0',
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '预算（成本）控制率=（项目当期实际支出成本-项目当期预算）/项目当期预算*100%',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '205',
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-064',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 08:06:11',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 08:06:11',
          'operator': null,
          'zjyt': null,
          'zjytText': null,
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_003',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '2f2b1964782ede64fdab3b27e4ce5828',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417918',
          'indName': '预算（成本）控制率',
          'isCommonInd': '1',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，若高出标准则每高出5%扣10分，扣完为止',
          'targetDescription': '考察项目预算成本是否控制在标准范围内',
          'targetCharacter': 2,
          'targetDirection': 5,
          'targetDirections': 5,
          'calculation': '%',
          'standardValue': null,
          'planValue': '0',
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '预算（成本）控制率=（项目当期实际支出成本-项目当期预算）/项目当期预算*100%',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': null,
          'targetAttribute': '2',
          'tradeStandardValue': null,
          'localStandardValue': null,
          'targetCatagory': 'LY-076',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 13:22:50',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-03-10 13:22:50',
          'operator': null,
          'zjyt': 'ZJYT-267',
          'zjytText': '信息化新建改造类',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_035',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': null,
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': 'b7516b749f2dc5da243f04763e143ff9',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417929',
          'indName': 'huigege',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': null,
          'targetDescription': 'asc',
          'targetCharacter': null,
          'targetDirection': null,
          'targetDirections': 2,
          'calculation': 'yi',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': null,
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': '21',
          'budYear': null,
          'funcCode': null,
          'targetAttribute': null,
          'tradeStandardValue': 'LY-007',
          'localStandardValue': null,
          'targetCatagory': 'HY_004',
          'targetVersion': null,
          'targetScope': '不定向使用',
          'openDate': '2021-07-01 19:23:33',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-07-01 19:23:33',
          'operator': '1000_admin',
          'zjyt': 'ZJYT-219',
          'zjytText': '病虫害监测与防控',
          'scope': null,
          'usedType': '1',
          'businessType': null,
          'targetClassify': null,
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': '7555fe798ce694aa8b71baa9bb54ba35',
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '93b7a335165fa7b74f968c718fdffcb3',
          'parentId': '7555fe798ce694aa8b71baa9bb54ba38',
          'indCode': '0001000417896',
          'indName': '义务教育生均公用经费',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': '达到计划值得满分，否则按实际值/计划值*指标分值计分',
          'targetDescription': '考察保障义务教育学校日常运转应达到的基准定额',
          'targetCharacter': 1,
          'targetDirection': 2,
          'targetDirections': 2,
          'calculation': '元',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': '数据统计',
          'targetSource': null,
          'mofDivCode': '100000000',
          'unitno': null,
          'budYear': null,
          'funcCode': '205',
          'targetAttribute': '1',
          'tradeStandardValue': 'LY-012',
          'localStandardValue': null,
          'targetCatagory': 'LY-064',
          'targetVersion': null,
          'targetScope': '1,2',
          'openDate': '2021-03-10 08:06:11',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': '2021-07-02 10:52:57',
          'isDeleted': 0,
          'createTime': '2021-03-10 08:06:11',
          'operator': '1000_admin',
          'zjyt': 'ZJYT-0177',
          'zjytText': '支持城乡义务教育发展',
          'scope': '1',
          'usedType': '1',
          'businessType': '1',
          'targetClassify': 'HY_003',
          'secondTargetId': '7555fe798ce694aa8b71baa9bb54ba38',
          'secondTargetCode': '00010004',
          'secondTargetName': '成本指标',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': '7555fe798ce694aa8b71baa9bb54ba35',
          'reserve14': null,
          'reserve15': null
        },
        {
          'indId': '7ec2df46e466a90db37394b66d481aed',
          'parentId': '7555fe798ce694aa8b71baa9aw54ba38',
          'indCode': '0001000513712',
          'indName': 'target',
          'isCommonInd': '0',
          'targetWeight': null,
          'standardDesc': null,
          'targetDescription': '低洼大王',
          'targetCharacter': null,
          'targetDirection': 1,
          'targetDirections': null,
          'calculation': 'yuan',
          'standardValue': null,
          'planValue': null,
          'historyValue': null,
          'actValue': null,
          'levelNo': 3,
          'calculated': null,
          'targetSource': '达瓦达瓦大挖',
          'mofDivCode': '100000000',
          'unitno': '21',
          'budYear': null,
          'funcCode': null,
          'targetAttribute': null,
          'tradeStandardValue': 'HY_001',
          'localStandardValue': null,
          'targetCatagory': 'LY-010',
          'targetVersion': null,
          'targetScope': '不定向使用',
          'openDate': '2021-07-02 22:48:02',
          'disabledDate': null,
          'isLeaf': 1,
          'isEnabled': 1,
          'updateTime': null,
          'isDeleted': 0,
          'createTime': '2021-07-02 22:48:02',
          'operator': '1000_admin',
          'zjyt': 'ZJYT-220',
          'zjytText': '扶贫贷款奖补和贴息',
          'scope': null,
          'usedType': '1',
          'businessType': null,
          'targetClassify': null,
          'secondTargetId': '7555fe798ce694aa8b71baa9aw54ba38',
          'secondTargetCode': '00010005',
          'secondTargetName': '基金预决算管理',
          'firstTargetId': '7555fe798ce694aa8b71baa9bb54ba35',
          'firstTargetCode': '0001',
          'firstTargetName': '产出指标',
          'reserve1': null,
          'reserve2': null,
          'reserve3': null,
          'reserve4': null,
          'reserve5': null,
          'reserve6': null,
          'reserve7': null,
          'reserve8': null,
          'reserve9': null,
          'reserve10': null,
          'reserve11': null,
          'reserve12': null,
          'reserve13': '7555fe798ce694aa8b71baa9bb54ba35',
          'reserve14': null,
          'reserve15': null
        }
      ],
      'total': 40,
      'size': 20,
      'current': 1,
      'orders': [],
      'searchCount': true,
      'pages': 2
    },
    'message': '查询成功！'
  },
  'caseDetailData': {
    'code': 0,
    'success': true,
    'content': {
      'templateId': 'CE4D4A0C1EAA4D9BBF1679E4FAD001B2',
      'viewData': {
        'baseInfo': {
          'pm_project_case_info$PRO_TOTAL_AMT': null,
          'pm_project_case_info$PRO_RESERVE4': null,
          'pm_project_case_info$DEP_UNITNAME': null,
          'pm_project_case_info$PRO_RESERVE3': null,
          'pm_project_case_info$PRO_RESERVE6': null,
          'pm_perf_goal_case_info$ADJUST_CONTENT': null,
          'pm_project_case_info$PRO_RESERVE5': null,
          'pm_perf_goal_case_info$FUN_RES_CODE': null,
          'pm_project_case_info$PRO_RESERVE8': null,
          'pm_project_case_info$PRO_RESERVE7': null,
          'pm_perf_goal_case_info$IS_DELETED': null,
          'pm_project_case_info$PRO_RESERVE9': null,
          'pm_project_case_info$CHARGE_TEL': null,
          'pm_perf_goal_case_info$PRO_TERM': null,
          'pm_project_case_info$PRO_BGTREVIEW': null,
          'pm_project_case_info$IS_USESET': null,
          'pm_project_case_info$MOF_DIV_CODE': '100000000',
          'pm_project_case_info$DEP_UNITNO': null,
          'pm_project_case_info$ONE_UP_MONEY': null,
          'pm_project_case_info$PRO_RESERVE2': null,
          'pm_project_case_info$PRO_RESERVE1': null,
          'pm_project_case_info$CHARGE_NAME': null,
          'pm_project_case_info$IS_END': null,
          'pm_project_case_info$SETUP_YEAR': '2021',
          'pm_project_case_info$ISPRIVATE': null,
          'pm_perf_goal_case_info$TEMPLATE_ID': 'CE4D4A0C1EAA4D9BBF1679E4FAD001B2',
          'pm_perf_goal_case_info$DISTRI_TYPE_CODE': null,
          'pm_project_case_info$IS_RES_PRO': null,
          'pm_perf_goal_case_info$PRO_NAME': null,
          'pm_perf_goal_case_info$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
          'pm_perf_goal_case_info$IS_PRE_PRO': null,
          'pm_project_case_info$CREATER': null,
          'pm_project_case_info$IS_PRE_PRO': null,
          'pm_perf_goal_case_info$MOF_DIV_CODE': '100000000',
          'pm_perf_goal_case_info$GOAL_AMT': null,
          'pm_perf_goal_case_info$PRO_NATURE': null,
          'pm_project_case_info$PRO_DEPREVIEW': null,
          'pm_perf_goal_case_info$PRO_ID': '0b350af7a5cba46cb519b8eade5558df',
          'pm_project_case_info$FINAL_MONEY': null,
          'pm_perf_goal_case_info$APP_TYPE': null,
          'pm_perf_goal_case_info$PRJ_LEVEL': null,
          'pm_project_case_info$TOW_UP_MONEY': null,
          'pm_project_case_info$PRO_STAGE': null,
          'pm_project_case_info$PRO_CODE': null,
          'pm_perf_goal_case_info$SCOI_INVEST_FUND': null,
          'pm_perf_goal_case_info$GOAL_RESERVE10': null,
          'pm_project_case_info$IS_TRACK': null,
          'pm_project_case_info$IS_SCIENTIFIC': null,
          'pm_perf_goal_case_info$PRO_DESC': null,
          'pm_project_case_info$PRO_RESERVE10': null,
          'pm_perf_goal_case_info$IS_CAPTIAL_CONS_PRO': null,
          'pm_project_case_info$APPLICANT_FILE': null,
          'pm_project_case_info$CEN_TRA_PRO_CODE': null,
          'pm_project_case_info$UPDATE_TIME': null,
          'pm_perf_goal_case_info$DRAFT_TEMPLATE_CODE': null,
          'pm_project_case_info$PRO_END_YEAR': null,
          'pm_perf_goal_case_info$PRO_CAT_CODE': null,
          'pm_project_case_info$NECESSITY': null,
          'pm_perf_goal_case_info$ISPRIVATE': null,
          'pm_perf_goal_case_info$ALL_TARGET': '总体目标111',
          'pm_perf_goal_case_info$ADJUSTED_MONEY': null,
          'pm_perf_goal_case_info$GOAL_STATUS': 99,
          'pm_project_case_info$MOF_AUD_OPINION_CODE': null,
          'pm_perf_goal_case_info$CHARGE_TEL': null,
          'pm_project_case_info$TRAOBJ_AGENCY_CODE': null,
          'pm_perf_goal_case_info$NECESSITY': null,
          'pm_project_case_info$SCOI_INVEST_FUND': null,
          'pm_perf_goal_case_info$TRAOBJ_AGENCY_CODE': null,
          'pm_perf_goal_case_info$PRO_SOURCE_CODE': null,
          'pm_project_case_info$ALL_DIRECTIONAL': null,
          'pm_perf_goal_case_info$APP_STAGE': null,
          'pm_perf_goal_case_info$OPERATOR': null,
          'pm_perf_goal_case_info$IS_END': null,
          'pm_perf_goal_case_info$CASE_ID': 'f67ad175896a0840e4e86acd869794e3',
          'pm_project_case_info$FUNC_CODE': null,
          'pm_perf_goal_case_info$SUB_MOF_CODE': null,
          'pm_perf_goal_case_info$GOAL_RESERVE8': null,
          'pm_perf_goal_case_info$GOAL_RESERVE7': null,
          'pm_perf_goal_case_info$ALL_STANDING': null,
          'pm_project_case_info$PRO_SOURCE_CODE': null,
          'pm_project_case_info$STORE_STATUS': null,
          'pm_perf_goal_case_info$RU_URL': null,
          'pm_perf_goal_case_info$GOAL_RESERVE9': null,
          'pm_perf_goal_case_info$CEN_TRA_PRO_CODE': null,
          'pm_perf_goal_case_info$GOAL_RESERVE2': null,
          'pm_perf_goal_case_info$GOAL_RESERVE1': null,
          'pm_perf_goal_case_info$GOAL_RESERVE4': null,
          'pm_perf_goal_case_info$GOAL_RESERVE3': null,
          'pm_perf_goal_case_info$GOAL_RESERVE6': null,
          'pm_perf_goal_case_info$GOAL_RESERVE5': null,
          'pm_perf_goal_case_info$IS_TRACK': null,
          'pm_perf_goal_case_info$PRO_CODE': null,
          'pm_project_case_info$ONE_DOWN_MONEY': null,
          'pm_perf_goal_case_info$ADJUST_REASON': null,
          'pm_perf_goal_case_info$SUB_DATE': null,
          'pm_project_case_info$DRAFT_TEMPLATE_CODE': null,
          'pm_perf_goal_case_info$IS_SCIENTIFIC': null,
          'pm_project_case_info$IS_DELETED': null,
          'pm_project_case_info$DECLARE_ATTRIBUTE': null,
          'pm_project_case_info$AGENCY_CODE': null,
          'pm_perf_goal_case_info$FUNC_CODE': null,
          'pm_project_case_info$APP_TYPE': '11',
          'pm_perf_goal_case_info$CREATE_TIME': null,
          'pm_perf_goal_case_info$DECLARE_ATTRIBUTE': null,
          'pm_project_case_info$PRO_NAME': '离退休过节费项目模板',
          'pm_project_case_info$PRO_CAT_CODE': '124',
          'pm_project_case_info$PRO_NATURE': null,
          'pm_project_case_info$PRO_DESC': null,
          'pm_perf_goal_case_info$FEASIBILITY': null,
          'pm_perf_goal_case_info$MOF_RESULT': null,
          'pm_perf_goal_case_info$PRO_START_YEAR': null,
          'pm_project_case_info$CREATE_TIME': null,
          'pm_perf_goal_case_info$ALL_DIRECTIONAL': null,
          'pm_project_case_info$FUN_RES_CODE': null,
          'pm_project_case_info$ALL_STANDING': null,
          'pm_perf_goal_case_info$APPLICANT_FILE': null,
          'pm_project_case_info$FEASIBILITY': null,
          'pm_perf_goal_case_info$IS_RES_PRO': null,
          'pm_perf_goal_case_info$PRO_STAGE': null,
          'pm_project_case_info$IS_CAPTIAL_CONS_PRO': null,
          'pm_perf_goal_case_info$IS_CASE': '1',
          'pm_project_case_info$PRO_TERM': null,
          'pm_perf_goal_case_info$STORE_STATUS': null,
          'pm_perf_goal_case_info$ADJUST_MONEY': null,
          'pm_project_case_info$PRO_ID': '0b350af7a5cba46cb519b8eade5558df',
          'pm_project_case_info$TOW_DOWN_MONEY': null,
          'pm_perf_goal_case_info$CREATER': null,
          'pm_perf_goal_case_info$CHARGE_NAME': null,
          'pm_project_case_info$DEP_AUD_OPINION_CODE': null,
          'pm_perf_goal_case_info$FISCAL_YEAR': '2021',
          'pm_perf_goal_case_info$UNIT_RESULT': null,
          'pm_project_case_info$PRJ_LEVEL': null,
          'pm_project_case_info$PRO_START_YEAR': null,
          'pm_perf_goal_case_info$YEAR_TARGET': '总体目标111',
          'pm_perf_goal_case_info$END_DATE': null,
          'pm_project_case_info$PARENT_ID': '0',
          'pm_project_case_info$DISTRI_TYPE_CODE': null,
          'pm_perf_goal_case_info$PRO_END_YEAR': null,
          'pm_project_case_info$MOF_DEP_CODE': null
        },
        'targetTree': {
          'pm_perf_case_indicator': [
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '0',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '0',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '产出指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '0001',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba35',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 1,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '5f88a15ffb1247cb9536186a5754cc64',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '数量指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00010001',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba50',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '5f88a15ffb1247cb9536186a5754cc64',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': null,
              'pm_perf_case_indicator$GT_ID': '083c4955d6bb4b818968c4f6158f4b1b',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': null,
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '5f88a15ffb1247cb9536186a5754cc64',
              'pm_perf_case_indicator$FILES_COUNT': null,
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': null,
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': null,
              'pm_perf_case_indicator$PARENT_GT_ID': '5f88a15ffb1247cb9536186a5754cc64',
              'pm_perf_case_indicator$EXPECT_VALUE': null,
              'pm_perf_case_indicator$IND_NAME': '支出率',
              'pm_perf_case_indicator$STANDARD_DESC': null,
              'pm_perf_case_indicator$GOTA_RESERVE10': null,
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': null,
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': null,
              'pm_perf_case_indicator$IND_CODE': '0001000100001',
              'pm_perf_case_indicator$IND_ID': null,
              'pm_perf_case_indicator$STANDARD_VALUE': null,
              'pm_perf_case_indicator$GOTA_RESERVE1': null,
              'pm_perf_case_indicator$id': '083c4955d6bb4b818968c4f6158f4b1b',
              'pm_perf_case_indicator$CALCULATION': null,
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': null,
              'pm_perf_case_indicator$TARGET_DESCRIPTION': null,
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 3,
              'pm_perf_case_indicator$GOTA_RESERVE5': null,
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': null,
              'pm_perf_case_indicator$GOTA_RESERVE3': null,
              'pm_perf_case_indicator$TARGET_REMARK': null,
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': null,
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': null,
              'pm_perf_case_indicator$GOTA_RESERVE8': null,
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': null,
              'pm_perf_case_indicator$GOTA_RESERVE7': null,
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': null
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': 'd21abf5b35e7494b861d038c722b0245',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '质量指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00010002',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba39',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': 'd21abf5b35e7494b861d038c722b0245',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': 'd3e31960e43c40d8b4c30bef5b50ad3b',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '时效指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00010003',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba40',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': 'd3e31960e43c40d8b4c30bef5b50ad3b',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': 'dc5b439a3c894d199648001a05030bf8',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '7686b6caa60f4c87abbcff923cfa2b9e',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '成本指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00010004',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba38',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': 'dc5b439a3c894d199648001a05030bf8',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '0',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '0',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '效益指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '0002',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba36',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 1,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '1e3835e93a8541ffa314304cdff222bd',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '经济效益指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00020001',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba42',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '1e3835e93a8541ffa314304cdff222bd',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '2d1c31841f1341edb79899cce8b60480',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '社会效益指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00020002',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba43',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '2d1c31841f1341edb79899cce8b60480',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': 'd036fa70d5ce4aa589d5107e5d102fb0',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '生态效益指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00020003',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba44',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': 'd036fa70d5ce4aa589d5107e5d102fb0',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '495a5f81f3ba4562b884bbab70e529b4',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '6aaf25dc9dc841c7869c2a12c016cfb5',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '可持续影响指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00020004',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba45',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '495a5f81f3ba4562b884bbab70e529b4',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '9f03e834908a44949e8000cdabfda8c6',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '0',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '0',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '满意度指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '0003',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba37',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '9f03e834908a44949e8000cdabfda8c6',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 1,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            },
            {
              'pm_perf_case_indicator$FINA_EXPECT_VALUE': '',
              'pm_perf_case_indicator$GT_ID': '8c9541c5b4114fb08756f89ffe4c35aa',
              'pm_perf_case_indicator$firstTargetName': null,
              'pm_perf_case_indicator$HYT_VALUE': '',
              'pm_perf_case_indicator$agencyCode': null,
              'pm_perf_case_indicator$TARGET_CHARACTER': null,
              'pm_perf_case_indicator$CREATER': 'A47B8EE13D0D0E20E050A8C06A0110FA',
              'pm_perf_case_indicator$parentId': '9f03e834908a44949e8000cdabfda8c6',
              'pm_perf_case_indicator$FILES_COUNT': '',
              'pm_perf_case_indicator$proCode': null,
              'pm_perf_case_indicator$ATTACH_NO': '',
              'pm_perf_case_indicator$TARGET_DIRECTION': null,
              'pm_perf_case_indicator$CREATE_TIME': '2021-07-22T05:58:43',
              'pm_perf_case_indicator$TARGET_TYPE': null,
              'pm_perf_case_indicator$GOAL_ID': '6ee2b2e5df51486d981a30d78e6093bf',
              'pm_perf_case_indicator$PEMS_IS_DELETED': null,
              'pm_perf_case_indicator$LYF_VALUE': '',
              'pm_perf_case_indicator$PARENT_GT_ID': '9f03e834908a44949e8000cdabfda8c6',
              'pm_perf_case_indicator$EXPECT_VALUE': '',
              'pm_perf_case_indicator$IND_NAME': '服务对象满意度指标',
              'pm_perf_case_indicator$STANDARD_DESC': '',
              'pm_perf_case_indicator$GOTA_RESERVE10': '',
              'pm_perf_case_indicator$secondTargetName': null,
              'pm_perf_case_indicator$modelTableName': 'PM_PERF_CASE_INDICATOR',
              'pm_perf_case_indicator$PEMS_AUDIT_OPINION': '',
              'pm_perf_case_indicator$secondTargetId': null,
              'pm_perf_case_indicator$FINA_AUDIT_OPINION': '',
              'pm_perf_case_indicator$IND_CODE': '00030001',
              'pm_perf_case_indicator$IND_ID': '7555fe798ce694aa8b71baa9bb54ba46',
              'pm_perf_case_indicator$STANDARD_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE1': '',
              'pm_perf_case_indicator$id': '8c9541c5b4114fb08756f89ffe4c35aa',
              'pm_perf_case_indicator$CALCULATION': '',
              'pm_perf_case_indicator$bigData': false,
              'pm_perf_case_indicator$LYT_VALUE': '',
              'pm_perf_case_indicator$TARGET_DESCRIPTION': '',
              'pm_perf_case_indicator$TYF_VALUE': null,
              'pm_perf_case_indicator$proName': null,
              'pm_perf_case_indicator$LEVEL_NO': 2,
              'pm_perf_case_indicator$GOTA_RESERVE5': '',
              'pm_perf_case_indicator$agencyName': null,
              'pm_perf_case_indicator$firstTargetId': null,
              'pm_perf_case_indicator$GOTA_RESERVE4': '',
              'pm_perf_case_indicator$GOTA_RESERVE3': '',
              'pm_perf_case_indicator$TARGET_REMARK': '',
              'pm_perf_case_indicator$CENTER_TARGET': null,
              'pm_perf_case_indicator$GOTA_RESERVE2': '',
              'pm_perf_case_indicator$FINA_IS_DELETED': null,
              'pm_perf_case_indicator$GOTA_RESERVE9': '',
              'pm_perf_case_indicator$GOTA_RESERVE8': '',
              'pm_perf_case_indicator$TARGET_WEIGHT': null,
              'pm_perf_case_indicator$CYT_VALUE': '',
              'pm_perf_case_indicator$GOTA_RESERVE7': '',
              'pm_perf_case_indicator$proId': null,
              'pm_perf_case_indicator$GOTA_RESERVE6': ''
            }
          ]
        }
      },
      'submitBo': null,
      'menuId': null
    },
    'message': null
  }
}

export default obj
