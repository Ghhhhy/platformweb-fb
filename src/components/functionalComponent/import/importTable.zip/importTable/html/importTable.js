/* eslint-disable no-undef */
// 导入表体弹框，支持解析嵌套表头   Author: Titans@2396757591@qq.com
const ImportTableGeneral = {
  name: 'InvoicTable',
  props: {
    importModalVisible: {
      type: Boolean
    },
    config: {
      type: Object,
      default() {
        return {
          reminder: '请使用最新的导入模板,若是第一次,请在下方下载。',
          instructions:
            '导入模版只能为Excel,文件大小不能大于10M,内容为纯文本或数字填写.模板中科目名称和科目编码不能为空,其他信息请查看模板中说明。',
          downloadTemplateText: '下载最新模版',
          downloadTemplate: false, // 是否显示下载模版按钮
          maxSize: 1024 * 1024 * 10, //  接受文件尺寸
          acceptType: 'xlsx', // 接受文件类型
          importThead: true, // 接受文件类型
          importTbody: false, // 接受文件类型
          showTheadSelect: true, // 显示表头行索引选择
          theadRowIndexStart: 1, // 表头开始行索引
          theadRowIndexEnd: 1, // 表头结束行索引
          filename: '' // 文件名
        }
      }
    }
  },
  data() {
    return {}
  },
  methods: {
    // 关闭对话框
    closeAndClear() {
      this.importModalVisible = false
    },
    onDownloadTemplateClick() {
      // 下载最新模板
      this.$emit('onDownloadTemplateClick', {}, this)
      if (typeof this.downloadTemplate === 'function') {
        this.downloadTemplate(this)
      }
    },
    onImportFileClick() {
      // 选择文件
      let self = this
      ImportTableUtilCb.importExcel({ config: this.config }, (data) => {
        self.curImportData = data
        self.config.filename = data.filename
      })
    },
    onImportClick(data) { // 导入
      let self = this
      this.$emit('onImportClick', self.curImportData, this)
      if (typeof this.importSuccess === 'function') {
        this.importSuccess(self.curImportData, this)
      }
    },
    onCancelClick() {
      this.$emit('onCancel', this.content)
      if (typeof this.cancel === 'function') {
        this.cancel(this)
      }
    }
  },
  mounted() {
    if (typeof this.importConfig === 'object') {
      Object.assign(this.config, this.importConfig)
    }
  },
  computed: {},
  watch: {
    importModalVisible: {
      handler(newVal) {
        this.$emit('update:importModalVisible', newVal)
      },
      immediate: true
    },
    config: {
      handler(newVal) {
      },
      deep: true,
      immediate: true
    }
  }
}
Vue.Component('BsImportTable', ImportTableGeneral)
