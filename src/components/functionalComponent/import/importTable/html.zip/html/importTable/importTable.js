/* eslint-disable no-undef */
// 导入表体弹框，支持解析嵌套表头   Author: Titans@2396757591@qq.com
class ImportTableUtils {
  constructor(gloabelConfig = {}) {
    let self = this
    this.XlsxTool = window.XLSX
    this.importGlobleConf = {
      maxSize: 1024 * 1024 * 10,
      acceptType: 'xlsx',
      theadRowIndexStart: 1,
      theadRowIndexEnd: 1,
      filename: ''
    }
    this.inputTag = document.createElement('input')
    this.inputTag.setAttribute('type', 'file')
    this.inputTag.setAttribute('accept', '.xlsx,.xls')
    this.inputTag.setAttribute('multiple', false)
    this.inputTag.addEventListener('change', function (e) {
      const files = e.target.files
      self.readWorkbookFromLocalFile(files)
    })
    this.importHistory = [] // 导入历史记录
  }
  importExcel({ config }, cb) { // 触发导入Excel动作
    this.configSource = config
    this.curImportGlobleConf = Object.assign({}, this.importGlobleConf, config)
    this.importcallback = cb
    this.selectFile(cb)
  }
  selectFile() { // 触发选取文件操作
    this.workbook = {}
    this.inputTag.value = null
    this.inputTag.click()
  }
  columnLabelToIndex(label) { // 获取列字母索引转化为数字索引
    if (!/[A-Z]+/.test(label.toLocaleUpperCase())) {
      throw new Error('Invalid parameter,Expect a String<Alphabetic>!')
    }
    let index = 0
    let chars = label.toLocaleUpperCase().split('')
    for (let i = 0; i < chars.length; i++) {
      index += (chars[i].charCodeAt() - 'A'.charCodeAt() + 1) * Math.pow(26, chars.length - i - 1)
    }
    return index - 1
  }
  getExcelColumnLabel(num) { // 获取索引获取列字母
    // 方法一 高效
    if (!/[0-9]+/.test(num)) {
      throw new Error('Invalid parameter,Expect a Number!')
    }
    let ordA = 'A'.charCodeAt(0)
    let ordZ = 'Z'.charCodeAt(0)
    let len = ordZ - ordA + 1
    let result = ''
    while (num >= 0) {
      result = String.fromCharCode(num % len + ordA) + result
      num = Math.floor(num / len) - 1
    }
    return result
    // 方法二 低效
    /*
        let temp = ''
        let i = Math.floor(Math.log(25.0 * (num) / 26.0 + 1) / Math.log(26)) + 1
        if (i > 1) {
          let sub = num - 26 * (Math.pow(26, i - 1) - 1) / 25
          for (let j = i; j > 0; j--) {
            temp = temp + String.fromCharCode(sub / Math.pow(26, j - 1) + 65)
            sub = sub % Math.pow(26, j - 1)
          }
        } else {
          temp = temp + String.fromCharCode(num + 65)
        }
        return temp
    */
  }
  transByteToSize(value) { // 换算文件大小
    if (value == null || value === '') {
      return '0 Bytes'
    }
    let unitArr = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    let index = 0
    let srcsize = parseFloat(value)
    index = Math.floor(Math.log(srcsize) / Math.log(1024))
    let size = srcsize / Math.pow(1024, index)
    //  保留的小数位数
    size = size.toFixed(2)
    return size + unitArr[index]
  }
  listToTreeByNestCodeLength(data, nestCodeKey) { // 根据nestCodeKey 长度 生成嵌套数据
    let map = {} // 构建map
    data.forEach(function (item) {
      map[item[nestCodeKey]] = item
      item.children = []
    })
    let treeData = []
    data.forEach(item => {
      let pnestCodeKey = item[nestCodeKey]
      pnestCodeKey = pnestCodeKey.slice(0, pnestCodeKey.length - 1)
      let mapItem = map[item[pnestCodeKey]]
      while (!mapItem && pnestCodeKey !== '') {
        pnestCodeKey = pnestCodeKey.slice(0, pnestCodeKey.length - 1)
        mapItem = map[pnestCodeKey]
      }
      if (mapItem) {
        (mapItem.children || (mapItem.children = [])).push(item)
      } else {
        treeData.push(item)
      }
    })
    return treeData
  }
  getSheetEffectiveCellInfo(refArea) { // 获取有效区域单元格信息 // 'A1:H1415'
    let refAreaArr = refArea.toLocaleUpperCase().split(':')
    let sheetEffectiveCellInfo = {
      startColLabel: refAreaArr[0].replace(/[0-9]/ig, ''),
      endColLabel: refAreaArr[1].replace(/[0-9]/ig, ''),
      startRowIndex: refAreaArr[0].replace(/[A-Z]/ig, ''),
      endRowIndex: refAreaArr[1].replace(/[A-Z]/ig, ''),
      colAreaLabel: []
    }
    sheetEffectiveCellInfo.startColIndex = this.columnLabelToIndex(sheetEffectiveCellInfo.startColLabel)
    sheetEffectiveCellInfo.endColIndex = this.columnLabelToIndex(sheetEffectiveCellInfo.endColLabel)
    for (let i = sheetEffectiveCellInfo.startColIndex; i <= sheetEffectiveCellInfo.endColIndex; i++) {
      sheetEffectiveCellInfo.colAreaLabel.push(this.getExcelColumnLabel(i))
    }
    return sheetEffectiveCellInfo
  }
  getMergesInfo(merges) { // 生成单元格合并映射
    let self = this
    let mergesMap = {
      mergesCell: {},
      mergesToCell: {}
    }
    merges && merges.forEach((item, index) => {
      let refcellTo = self.getExcelColumnLabel(item.s.c) + (+item.s.r + 1)
      mergesMap.mergesCell[refcellTo] = {
        refcell: refcellTo,
        startColLabel: self.getExcelColumnLabel(item.s.c),
        endColLabel: self.getExcelColumnLabel(item.e.c),
        startColIndex: item.s.c,
        endColIndex: item.e.c,
        startRowIndex: +item.s.r + 1,
        endRowIndex: +item.s.r + 1
      }
      for (let r = item.s.r; r <= item.e.r; r++) {
        for (let c = item.s.c; c <= item.e.c; c++) {
          let refcell = self.getExcelColumnLabel(c) + (+r + 1)
          mergesMap.mergesToCell[refcell] = refcellTo
        }
      }
    })
    return mergesMap
  }
  generateTheadArr(sheetDataSource) { // 根据已有数据和单元格合并映射 生成完整表头Array
    let { theadRowIndexStart, theadRowIndexEnd } = this.curImportGlobleConf
    theadRowIndexEnd = theadRowIndexEnd > theadRowIndexStart ? +theadRowIndexEnd + 1 : +theadRowIndexStart + 1
    let { colAreaLabel } = this.curSheetEffectiveCellInfo
    let { mergesToCell } = this.getMergesInfo(sheetDataSource['!merges'])
    let headMap = {}
    let headAarryAll = []
    for (let i = theadRowIndexStart; i < theadRowIndexEnd; i++) {
      let headAarry = []
      for (let collabel of colAreaLabel) {
        if (sheetDataSource[collabel + i]) {
          let cellitem = {
            // rowIndex: i,
            collabel: collabel,
            //  mergesInfo: mergesCell[collabel + i],
            title: sheetDataSource[collabel + i].v
          }
          headAarry.push(cellitem)
          headMap[collabel + i] = cellitem
        } else {
          let cellitem = mergesToCell[collabel + i]
          headAarry.push(cellitem)
          headMap[collabel + i] = cellitem
        }
      }
      headAarryAll.push(headAarry)
    }
    return { headAarryAll, headMap }
  }
  generateThead(sheetDataSource) { // 根据表头完整数据和单元格合并映射生成嵌套表头
    let { headAarryAll, headMap } = this.generateTheadArr(sheetDataSource)
    let { theadRowIndexStart } = this.curImportGlobleConf
    let theadArrReault = []
    headAarryAll.forEach((item, index) => {
      item.forEach((col, colIndex) => {
        if (index === 0) {
          if (typeof col === 'object') {
            theadArrReault.push(col)
          }
        } else {
          if (typeof col === 'object') {
            let pCellRef = headMap[col.collabel + (+index + theadRowIndexStart - 1)]
            if (typeof pCellRef === 'object') {
              (pCellRef.children || (pCellRef.children = [])).push(col) // 这里判断mapItem中是否存在child
            } else {
              while (typeof pCellRef !== 'object') {
                pCellRef = headMap[pCellRef]
              }
              (pCellRef.children || (pCellRef.children = [])).push(col) // 这里判断mapItem中是否存在child
            }
          }
        }
      })
    })
    return theadArrReault
  }
  generateTheadTreeTolist(data, level = 1, pid = '', alltille, list = []) { // 嵌套head转换成平行数据并生成id和pid
    let self = this
    data.forEach((item, index) => {
      item.pid = pid
      item.id = pid + String(index).padStart(4, '0')
      item.columnorder = pid + String(index).padStart(4, '0')
      item.columnlevel = level
      item.alltille = alltille ? alltille + '。' + item.title : item.title
      list.push(item)
      if (Array.isArray(item.children) && item.children.length) {
        self.generateTheadTreeTolist(item.children, level + 1, item.id, item.alltille, list)
      }
    })
    return list
  }
  generateTheadLowestLevel(data, map = { lowestLevelArr: [], LowestLevelMap: {} }) { // 根据嵌套表头生成数据低级映射，用来处理解析表体
    let self = this
    data.forEach((item, index) => {
      if ((Array.isArray(item.children) && !item.children.length) || !Array.isArray(item.children)) {
        let titleArr = item.title.split('::')
        let curLowerstLevel = Object.assign(item, {
          title: titleArr[0],
          field: titleArr[1] || 'column' + String(map.lowestLevelArr.length),
          columnname: titleArr[0],
          columntype: 1,
          renderType: titleArr[2] || '$vxeInput' // 新全局下拉树: $vxeTree，文本数字输入: $vxeInput，下拉选择: $vxeSelect，计算渲染器: $vxeCalculate，金额输入: $vxeMoney，下拉文本框: $vxeEditDownTextarea，天数: $vxeDays，时间日期: $vxeTime，单选: $vxeRadio，多选: $vxeCheckbox，间隔时间或数值选择输入渲染器: $vxeIntervar，开关: $vxeSwitch，进度条: vxeProgress。其中，条件渲染器，进度条
        })
        map.lowestLevelArr.push(curLowerstLevel)
        map.LowestLevelMap[curLowerstLevel.collabel] = curLowerstLevel
      } else {
        Object.assign(item, {
          field: '',
          columnname: item.title,
          columntype: 1,
          renderType: '' // 新全局下拉树: $vxeTree，文本数字输入: $vxeInput，下拉选择: $vxeSelect，计算渲染器: $vxeCalculate，金额输入: $vxeMoney，下拉文本框: $vxeEditDownTextarea，天数: $vxeDays，时间日期: $vxeTime，单选: $vxeRadio，多选: $vxeCheckbox，间隔时间或数值选择输入渲染器: $vxeIntervar，开关: $vxeSwitch，进度条: vxeProgress。其中，条件渲染器，进度条
        })
        self.generateTheadLowestLevel(item.children, map)
      }
    })
    return map
  }
  generateTbody(data, { titleToFieldMap, tbodyStartRowIndex }) { // 生成表体
    return data.slice(tbodyStartRowIndex).map((row, rowIndex) => {
      let obj = {}
      Object.keys(titleToFieldMap).forEach((title, titleIndex) => {
        obj[titleToFieldMap[title]] = row[title] || ''
      })
      return obj
    })
  }
  generateTheadAndTbody(sheetDataSource) { // 生成表头(嵌套表头和单表头)和表体
    this.curSheetEffectiveCellInfo = this.getSheetEffectiveCellInfo(sheetDataSource['!ref'])
    let theadResult = this.generateThead(sheetDataSource)
    let { lowestLevelArr } = this.generateTheadLowestLevel(theadResult)
    let { theadRowIndexEnd } = this.curImportGlobleConf
    let { endRowIndex } = this.curSheetEffectiveCellInfo
    let tbodyResult = []
    if (+endRowIndex > +theadRowIndexEnd) {
      for (let rowIndex = +theadRowIndexEnd + 1; rowIndex <= endRowIndex; rowIndex++) {
        let row = {}
        lowestLevelArr.forEach((column, columnIndex) => {
          row[column.field] = sheetDataSource[column.collabel + rowIndex] ? sheetDataSource[column.collabel + rowIndex].v : ''
        })
        tbodyResult.push(row)
      }
    }
    return {
      tbody: tbodyResult,
      tbodyNest: this.listToTreeByNestCodeLength(tbodyResult, lowestLevelArr[0].field),
      theadNest: theadResult,
      theadList: this.generateTheadTreeTolist(theadResult),
      theadSing: lowestLevelArr,
      sheetEffectiveCellInfo: this.curSheetEffectiveCellInfo,
      sheetDataSource: sheetDataSource
    }
  }
  readWorkbookFromLocalFile(files) { // 读取导入的excel文件数据
    let self = this
    if (!files.length) {
      return
    }
    let { name, size, type } = files[0]
    let reader = new FileReader()
    reader.onload = function (e) {
      let data = e.target.result
      let workbook = self.XlsxTool.read(data, { type: 'binary' })
      self.workbook = workbook
      let excelDataMap = {}
      let excelDataArray = []
      let firstSheetData = []
      for (let i = 0; i < workbook.SheetNames.length; i++) {
        // 如果多个shheet,这地方可以设置一个弹框去填写表头单元格信息 或者 可以 表格第一行恒定配置表头说明来解析说明获取解析的一些必须数据
        let sheetData = self.generateTheadAndTbody(workbook.Sheets[workbook.SheetNames[i]])
        let curSheetData = {
          sheetName: workbook.SheetNames[i],
          data: sheetData
        }
        excelDataMap[workbook.SheetNames[i]] = curSheetData
        excelDataArray[i] = curSheetData
        if (i === 0) {
          firstSheetData = sheetData
        }
      }
      // filename  name.replace(/.xlsx$|.xls$/,'')

      let curImportData = { importUtil: self, curImportConfig: self.curImportGlobleConf, filename: name, name: name.replace(/.xlsx$|.xls$/, ''), type: type, size: self.transByteToSize(size), import: workbook, excelDataMap, firstSheetData, excelDataArray }
      self.importcallback(curImportData)
      self.importHistory.push(curImportData)
      self.importHistory = self.importHistory.reverse().slice(0, 20).reverse()
    }
    reader.readAsBinaryString(files[0])
  }
}
const ImportTableUtilCb = new ImportTableUtils()
const ImportTableGeneral = {
  name: 'InvoicTable',
  template: `
   <div class="idtu-template-generate">
    <vxe-modal
      v-model="importModalVisible"
      width="800"
      title="导入"
      :zIndex='1000'
      @click="closeAndClear"
      @cancel="onCancelClick"
    >
    <template>
      <div class="import-download-template-up">
        <div v-if="config.downloadTemplate">
          <div class="idtu-tip">
            {{ config.reminder }}
          </div>
          <div class="idtu-download-template">
            <vxe-button
              class="btn"
              content="下载最新模板"
              @click="onDownloadTemplateClick"
            />
          </div>
        </div>

        <div class="idtu-import">
          <vxe-form
            size="medium"
            title-width="150"
            title-align="right"
            align="left"
            title-colon
          >
            <vxe-form-item v-if="config.showTheadSelect" title="导入说明" :span="24">
              <div class="idtu-import-tip">
                {{ config.instructions }}
              </div>
            </vxe-form-item>
            <vxe-form-item title="导入选项" :span="24">
              <template v-slot>
                <div class="vxe-checkbox-group fn-inline">
                  <vxe-checkbox
                    v-model="config.importThead"
                    label="isEOnlySourceField"
                    content="导入表头"
                    size="medium"
                  />
                  <vxe-checkbox
                    v-model="config.importTbody"
                    label="isExportOnlySourceField"
                    content="导入表体"
                    size="medium"
                  />
                </div>
              </template>
            </vxe-form-item>
            <vxe-form-item v-if="config.showTheadSelect" title="指定表头行索引" :span="24">
              <vxe-input v-model="config.theadRowIndexStart" placeholder="开始行索引" type="integer" />
              <span class="fgx">-</span>
              <vxe-input v-model="config.theadRowIndexEnd" placeholder="结束行索引" type="integer" />
            </vxe-form-item>
            <vxe-form-item title="点击导入" :span="24">
              <vxe-button
                class="download-button-btn"
                type="text"
                status="primary"
                icon="fa fa-upload"
                content="点击导入文件"
                @click="onImportFileClick"
              />
            </vxe-form-item>
            <vxe-form-item v-if="config.filename !== ''" title="导入文件名" :span="24">
              <div class="idtu-importFile-tip">
                {{ config.filename }}
              </div>
            </vxe-form-item>
          </vxe-form>
        </div>
        <div class="idtu-import-btn">
          <vxe-button
            class="download-button-btn"
            status="primary"
            icon="fa fa-save"
            :disabled="config.filename === ''"
            content="导入"
            @click="onImportClick"
          />
        </div>
      </div>
      </template>
    </vxe-modal>
  </div>
  `,
  props: {
    importModalVisible: {
      type: Boolean
    },
    config: {
      type: Object,
      default() {
        return {
          reminder: '请使用最新的导入模板,若是第一次,请在下方下载。',
          instructions:
            '导入模版只能为Excel,文件大小不能大于10M,内容为纯文本或数字填写.模板中科目名称和科目编码不能为空,其他信息请查看模板中说明。',
          downloadTemplateText: '下载最新模版',
          downloadTemplate: false, // 是否显示下载模版按钮
          maxSize: 1024 * 1024 * 10, //  接受文件尺寸
          acceptType: 'xlsx', // 接受文件类型
          importThead: true, // 接受文件类型
          importTbody: false, // 接受文件类型
          showTheadSelect: true, // 显示表头行索引选择
          theadRowIndexStart: 1, // 表头开始行索引
          theadRowIndexEnd: 1, // 表头结束行索引
          filename: '' // 文件名
        }
      }
    }
  },
  data() {
    return {}
  },
  methods: {
    // 关闭对话框
    closeAndClear() {
      this.importModalVisible = false
    },
    onDownloadTemplateClick() {
      // 下载最新模板
      this.$emit('onDownloadTemplateClick', {}, this)
      if (typeof this.downloadTemplate === 'function') {
        this.downloadTemplate(this)
      }
    },
    onImportFileClick() {
      // 选择文件
      let self = this
      ImportTableUtilCb.importExcel({ config: this.config }, (data) => {
        self.curImportData = data
        self.config.filename = data.filename
      })
    },
    onImportClick(data) { // 导入
      let self = this
      this.$emit('onImportClick', self.curImportData, this)
      if (typeof this.importSuccess === 'function') {
        this.importSuccess(self.curImportData, this)
      }
    },
    onCancelClick() {
      this.$emit('onCancel', this.content)
      if (typeof this.cancel === 'function') {
        this.cancel(this)
      }
    }
  },
  mounted() {
    if (typeof this.importConfig === 'object') {
      Object.assign(this.config, this.importConfig)
    }
  },
  computed: {},
  watch: {
    importModalVisible: {
      handler(newVal) {
        this.$emit('update:importModalVisible', newVal)
      },
      immediate: true
    },
    config: {
      handler(newVal) {
      },
      deep: true,
      immediate: true
    }
  }
}
window.Vue.component('BsImportTable', ImportTableGeneral)

let ImportTableConstructor = window.Vue.extend(ImportTableGeneral)
let BsFcImportTable = function (options) {
  options = options || {}
  let instance = new ImportTableConstructor({
    data: options
  })
  let userOnClose = options.cancel
  let importSuccess = options.importSuccess
  options.importSuccess = function (obj, context) {
    BsFcImportTable.importSuccessAndDestroy(instance, importSuccess, obj, context)
  }
  options.cancel = function (context) {
    BsFcImportTable.closeAndDestroy(instance, userOnClose, context)
  }
  instance.$mount()
  document.body.appendChild(instance.$el)
  instance.importModalVisible = true
  return instance
}
BsFcImportTable.importSuccessAndDestroy = function (instance, importTableDataCb, obj, context) {
  document.body.removeChild(instance.$el)
  instance.$destroy()
  if (typeof importTableDataCb === 'function') {
    importTableDataCb(obj, context)
  }
}
BsFcImportTable.closeAndDestroy = function (instance, userOnClose) {
  document.body.removeChild(instance.$el)
  instance.$destroy()
  if (typeof userOnClose === 'function') {
    userOnClose(instance)
  }
}
window.BsFcImportTableCb = BsFcImportTable

function queryAjax(obj) { // 全局请求拦截函数
  /* Ajax异步请求全局处理 */
  var argobj = {
    type: 'post',
    url: '',
    queryParams: {},
    beforeSendCallback: function () { },
    completeCallback: function () { }
  }
  Object.assign(argobj, obj)
  /*
   * queryUrl：请求地址；
   * queryParams：请求Data
   * beforeSendCallback：发送请求前要执行的回调函数
   * completeCallback：请求完成后要执行的回调函数
   * isfjroolUrl：是否带根路径
   * 需要引入JQuery2.5版本及以上，解决异步调用，这里可对全局ajax请求做超时或错误处理，全局打印请求结果
   * */
  var accessToken = '11111'
  var requesthead = {
    url: argobj.Origin ? (argobj.Origin + argobj.url) : argobj.url,
    data: argobj.data,
    async: false,
    dataType: 'json',
    type: argobj.type,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': argobj.type === 'post' ? 'application/json;charset=UTF-8' : 'application/x-www-form-urlencoded;charset=utf-8',
      tokenid: accessToken
    },
    beforeSend: function (XHR) {
      // 这里可全局处理加载
      argobj.beforeSendCallback(XHR)
    },
    complete: function (XHR) {
      argobj.completeCallback(XHR)
      // 需要冲内存中获取最新的数据
      // sesionTimeOutHandle(XHR); //系统超时处理自定义
    },
    success: function (res) {
      console.log(res)
    },
    error: function (err) {
      // 这里可全局处理error
      console.log(err)
    }
  }
  var responseResult = $.ajax(requesthead)
  var response = responseResult.responseJSON
  if (!response || response.length == 0) return
  if (responseResult.status === 200 && response.data.code) {
    switch (response.data.code) {
      case (401):
        console.log('Unauthorized,表示用户没有权限(令牌、用户名、密码错误)')
        break
      case (400):
        console.log('Invalid Request,用户发出的请求有错误')
        break
      case (403):
        console.log('Forbidden, 表示用户得到授权(与 401 错误相对)，但是访问是被禁止的')
        break
      case (404):
        console.log('Not Found,用户发出的请求针对的是不存在的记录，服务器没有进行操作')
        break
      case (406):
        console.log('Not Acceptable， 用户请求的格式不可得(比如用户请求 JSON格式，但是只有XMLs格式)。')
        break
      case (422):
        console.log('Unprocesable entitz， 当创建一个对象时，发生一个验证错误')
        break
      case (500):
        console.log('Internal Server Error， 服务器发生错误，用户将无法判断发出的请求是否成功。')
        break
      default:
        break
    }
    return response
  } else {
    return {
      data: {
        code: 0,
        errorInfor: responseResult
      },
      code: 0
    }
  }
}
