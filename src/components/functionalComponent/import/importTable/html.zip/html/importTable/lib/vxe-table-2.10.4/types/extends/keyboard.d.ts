import { VXETableComponent } from '../component'

/**
 * 键盘导航
 */
export declare class Keyboard extends VXETableComponent {}
