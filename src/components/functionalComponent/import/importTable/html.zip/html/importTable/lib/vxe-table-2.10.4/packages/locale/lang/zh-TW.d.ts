import Language from './language'

/**
 * 繁體中文 - 台湾
 */
declare const zhTW: Language

export default zhTW