import Language from './language'

/**
 * 繁體中文 - 香港
 */
declare const zhHK: Language

export default zhHK