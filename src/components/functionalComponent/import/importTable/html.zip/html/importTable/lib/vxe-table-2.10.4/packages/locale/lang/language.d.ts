export interface Language {
  [propName: string]: any;
}

export default Language