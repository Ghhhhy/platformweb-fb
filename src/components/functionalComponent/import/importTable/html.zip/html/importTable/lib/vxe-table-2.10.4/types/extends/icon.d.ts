import { VXETableComponent } from '../component'

/**
 * 内置图标库
 */
export declare class Icon extends VXETableComponent {}
