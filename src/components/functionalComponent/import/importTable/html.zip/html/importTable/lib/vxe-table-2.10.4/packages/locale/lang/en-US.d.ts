import Language from './language'

/**
 * English
 */
declare const enUS: Language

export default enUS