import * as methods from './methods'

export default methods