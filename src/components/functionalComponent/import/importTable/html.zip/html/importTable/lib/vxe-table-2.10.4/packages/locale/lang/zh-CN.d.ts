import Language from './language'

/**
 * 简体中文
 */
declare const zhCN: Language

export default zhCN