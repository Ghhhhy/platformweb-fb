import Language from './language'

/**
 * 繁体中文
 */
declare const zhTC: Language

export default zhTC