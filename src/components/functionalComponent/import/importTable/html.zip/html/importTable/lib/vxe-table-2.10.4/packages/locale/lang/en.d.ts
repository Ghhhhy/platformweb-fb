import enUS from './en-US'

export default enUS
