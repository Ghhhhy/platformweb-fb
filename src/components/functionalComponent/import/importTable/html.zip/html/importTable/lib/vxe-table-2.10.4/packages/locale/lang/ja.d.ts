import jaJP from './ja-JP'

/**
 * 已废弃，被 ja-JP 替换
 */
export default jaJP
