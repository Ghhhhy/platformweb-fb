import Language from './language'

/**
 * ジャパン
 */
declare const jaJP: Language

export default jaJP