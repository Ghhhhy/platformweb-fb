import Language from './language'

/**
 * 繁體中文 - 澳门
 */
declare const zhMO: Language

export default zhMO